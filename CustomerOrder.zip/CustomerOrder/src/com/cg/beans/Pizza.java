package com.cg.beans;

import java.io.Serializable;
import java.util.Date;

public class Pizza implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int orderId;
	private int custId;
	private double totalprice;
	private Date orderdate;
	public Pizza() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Pizza(int orderId, int custId, double totalprice, Date orderdate) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.totalprice = totalprice;
		this.orderdate = orderdate;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public Date getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}
	@Override
	public String toString() {
		return "Pizza [orderId=" + orderId + ", custId=" + custId + ", totalprice=" + totalprice + ", orderdate="
				+ orderdate + "]";
	}
	

}
