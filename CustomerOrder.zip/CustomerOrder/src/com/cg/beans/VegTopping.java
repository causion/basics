package com.cg.beans;

public enum VegTopping {
	CAPSICUM(30),MUSHROOM(50),JALAPENO(70),PANNER(85);
	
	
	private double price;

	private VegTopping(double price) {
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	

}
