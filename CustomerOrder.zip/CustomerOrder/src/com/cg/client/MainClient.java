package com.cg.client;

import java.util.Scanner;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.beans.VegTopping;
import com.cg.exception.PizzaException;
import com.cg.service.IPizzaOrderService;
import com.cg.service.PizzaOrderServiceImpl;

public class MainClient {
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		IPizzaOrderService pizzaService=new PizzaOrderServiceImpl();
		int option=0;
		
		System.out.println("************Welcome to JavaPizza*********");
		while(true) {
			
			System.out.println("1.PlaceOrder\n2.Display Order\n3.Exit");
			System.out.println("Enter option");
			option=scanner.nextInt();
			switch(option) {
			case 1:{
				System.out.println("Enter Name:");
				String custName=scanner.next();
				System.out.println("Enter Address:");
				String custAddress=scanner.next();
				System.out.println("Enter phone:");
				long custphone=scanner.nextLong();
				System.out.println("PizzaToppings\t\tprice(inRs)");
				System.out.println("----------------------------");
				for(VegTopping topping : VegTopping.values()) {
					System.out.println(topping+"\t\t"+topping.getPrice());
				}
				
				System.out.println("----------------------------");
				System.out.println("Type of topping prefered:");
				String topping=scanner.next();
				double totalprice=0;
				double price=0;
				if(topping.equalsIgnoreCase("CAPSICUM")) {
					price=VegTopping.CAPSICUM.getPrice();
				}else if(topping.equalsIgnoreCase("MUSHROOM")) {
					price=VegTopping.MUSHROOM.getPrice();
				}else if(topping.equalsIgnoreCase("JALAPENO")) {
					price=VegTopping.JALAPENO.getPrice();
				}else if(topping.equalsIgnoreCase("PANNER")) {
					price=VegTopping.PANNER.getPrice();
				}else {
					System.out.println("please enter available Toppings only");
				}
				totalprice=350+price+(price*4/100);
				Customer customer=new Customer(custName,custAddress,custphone);
				Pizza pizza=new Pizza();
				pizza.setTotalprice(totalprice);
				try {
					int status=pizzaService.placeOrder(customer, pizza);
					if(status>0) {
						System.out.println("your order is placed your order Id is:"+status);
					}else {
						System.out.println("Your order not placed try again");
					}
					}catch(PizzaException e) {
						e.printStackTrace();						
					}				
												
				}
			break;
			case 2:{
						System.out.println("Enter Order Id:");
						int orderId=scanner.nextInt();
						Pizza pizza;
						try {
							pizza=pizzaService.displayOrder(orderId);
							System.out.println("\nOrder Id\t:"+pizza.getOrderId());
							System.out.println("\nTotal Price\t:"+pizza.getTotalprice());
							System.out.println("\nOrder Date\t:"+pizza.getOrderdate());
							}catch(PizzaException e) {
							e.printStackTrace();
							}
						}
						break;
				case 3:{
						System.out.println("Exit...");
						System.exit(0);
						}break;
				
			default:System.out.println("Enter option 1 to 3 only");
			       break;
			}
		}
	}
}




