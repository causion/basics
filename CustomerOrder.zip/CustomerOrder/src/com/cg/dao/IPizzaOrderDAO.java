package com.cg.dao;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.exception.PizzaException;

public interface IPizzaOrderDAO {
	
	
	int placeOrder(Customer customer,Pizza pizza) throws PizzaException;
	Pizza display(int orderId) throws PizzaException;

}
