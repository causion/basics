package com.cg.dao;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.exception.PizzaException;
import com.cg.util.DBConnection;

public class PizzaOrderDAOImpl implements IPizzaOrderDAO {
	Logger log=Logger.getLogger(PizzaOrderDAOImpl.class);
    Connection connection=null;
    PreparedStatement statement=null;
    ResultSet resultSet=null;
    int row=0;	


	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException {
		log.info("place order started");
		connection=DBConnection.getConnection();
		log.info("Connection Established");
		int custId=0;
		int orderId=0;
		try {
			statement=connection.prepareStatement("select customerseq9.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				custId=resultSet.getInt(1);
			}
			log.info("Customer Id is"+custId);
			statement=connection.prepareStatement("select pizzaseq9.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				orderId=resultSet.getInt(1);
			}
			log.info("Order Id is"+orderId);
			statement=connection.prepareStatement("insert into customer_details values(?,?,?,?)");
			statement.setInt(1, custId);
			statement.setString(2, customer.getCustName());
			statement.setString(3, customer.getCustAddress());
			statement.setLong(4, customer.getCustPhone());
			row=statement.executeUpdate();
			log.info("Customer added successfully");
			
			
			statement=connection.prepareStatement("insert into pizza_details values(?,?,?,sysdate)");
			statement.setInt(1, orderId);
			statement.setInt(2, custId);
			statement.setDouble(3, pizza.getTotalprice());
			int row1=statement.executeUpdate();
			log.info("Order details added successfully");
			if(row>0 && row1>0) {
				return orderId;
			}
			
		}catch(SQLException e) {
			log.error(e.getMessage());
			throw new PizzaException("Unable to place the order:"+e.getMessage());
			
		}
		return 0;
	}

	@Override
	public Pizza display(int orderId) throws PizzaException {
		log.info("Display order started...");
		connection=DBConnection.getConnection();
		log.info("Connection Established");
		Pizza pizza=null;
		try {
			statement=connection.prepareStatement("select * from pizza_details where orderid=?");
			statement.setInt(1, orderId);
			resultSet=statement.executeQuery();
			if(resultSet.next()){
				log.info("order details are found");
				pizza=new Pizza();
				pizza.setOrderId(resultSet.getInt(1));
				pizza.setCustId(resultSet.getInt(2));
				pizza.setTotalprice(resultSet.getDouble(3));
				pizza.setOrderdate(new Date(resultSet.getDate(4).getTime()));
				
				
			}
		} catch (SQLException e) {
			log.error("Display order exception raised is:"+e.getMessage());
			throw new PizzaException("Unable to display the details"+e.getMessage());
		}
		
		return pizza;
	}


}
