package com.cg.service;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.exception.PizzaException;

public interface IPizzaOrderService {
	
	int placeOrder(Customer customer,Pizza pizza) throws PizzaException;
	Pizza displayOrder(int orderId) throws PizzaException;
	

}
