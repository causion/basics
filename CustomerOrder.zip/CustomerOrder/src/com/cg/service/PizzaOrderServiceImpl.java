package com.cg.service;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.dao.IPizzaOrderDAO;
import com.cg.dao.PizzaOrderDAOImpl;
import com.cg.exception.PizzaException;

public class PizzaOrderServiceImpl implements IPizzaOrderService {
	IPizzaOrderDAO pizzaOrderDao=new PizzaOrderDAOImpl();

	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException {
		// TODO Auto-generated method stub
		return  pizzaOrderDao.placeOrder(customer, pizza);
	}

	@Override
	public Pizza displayOrder(int orderId) throws PizzaException {
		// TODO Auto-generated method stub
		return pizzaOrderDao.display(orderId);
	}

}
