package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.beans.Customer;
import com.cg.beans.Pizza;
import com.cg.dao.IPizzaOrderDAO;
import com.cg.dao.PizzaOrderDAOImpl;
import com.cg.exception.PizzaException;

public class PizzaOrderDaoImplTest {
	
	static IPizzaOrderDAO pizzaOrderDao;
	Customer customer;
	Pizza pizza;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		pizzaOrderDao=new PizzaOrderDAOImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		pizzaOrderDao=null;
	}

	@Before
	public void setUp() throws Exception {
		customer=new Customer();
		pizza=new Pizza();
		
	}

	@After
	public void tearDown() throws Exception {
	    customer=null;
	    pizza=null;
	}

	@Test
	public void testPlaceOrder() throws PizzaException {
		customer.setCustName("priya");
		customer.setCustAddress("Blr");
		customer.setCustPhone(969868);
		pizza.setTotalprice(666);
		assertTrue(pizzaOrderDao.placeOrder(customer, pizza)>0);
		
	}

	@Test
	public void testDisplay() throws PizzaException {
		assertTrue(pizzaOrderDao.display(2000)!=null);
	}

}
