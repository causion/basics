package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.HotelEntry;
import com.capgemini.service.IBookingService;

@Controller
public class BookingController {
	
	@Autowired
	private HotelEntry HotelEntry;
	
	@Autowired
	private IBookingService iBookingService;
	
	
	@RequestMapping("/")
	public ModelAndView viewAllHotelDetails() {
		ModelAndView modelAndView = new ModelAndView();
		List<HotelEntry> hotelDetails = null;
		hotelDetails = iBookingService.viewAllHotelDetails();
		modelAndView.addObject("hotelDetails", hotelDetails);
		modelAndView.setViewName("HotelDetails");
		return modelAndView;
	}
	
	@RequestMapping("/bookingconfirmationpage")
	public ModelAndView bookingConfiramtion(@RequestParam String hotelName) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("hotelName", hotelName);
		modelAndView.setViewName("BookingConfirmation");
		return modelAndView;
	}
	
	
	


}
