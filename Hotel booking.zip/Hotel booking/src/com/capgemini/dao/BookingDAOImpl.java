package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.exception.BookingException;
import com.capgemini.model.HotelEntry;

@Repository
public class BookingDAOImpl implements IBookingDAO {

	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<HotelEntry> viewAllHotelDetails(){
		TypedQuery<HotelEntry> query = entityManager.createQuery("from HotelEntry", HotelEntry.class);
		List<HotelEntry> hotelDetails = query.getResultList();
		return hotelDetails;
	}

}