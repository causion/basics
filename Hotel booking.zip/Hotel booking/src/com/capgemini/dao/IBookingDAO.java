package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.HotelEntry;




public interface IBookingDAO {
	
	public List<HotelEntry> viewAllHotelDetails();
}
