package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="bookingdetails")
public class HotelBooking {
	
	@Id
	private int customerId;
	
	private String customerName;
	private int hotelId;
	private String toDate;
	private String fromDate;
	private int noofRooms;
	public HotelBooking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public int getNoofRooms() {
		return noofRooms;
	}
	public void setNoofRooms(int noofRooms) {
		this.noofRooms = noofRooms;
	}
	public HotelBooking(int customerId, String customerName, int hotelId, String toDate, String fromDate,
			int noofRooms) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.hotelId = hotelId;
		this.toDate = toDate;
		this.fromDate = fromDate;
		this.noofRooms = noofRooms;
	}
	@Override
	public String toString() {
		return "HotelBooking [customerId=" + customerId + ", customerName=" + customerName + ", hotelId=" + hotelId
				+ ", toDate=" + toDate + ", fromDate=" + fromDate + ", noofRooms=" + noofRooms + "]";
	}

}
