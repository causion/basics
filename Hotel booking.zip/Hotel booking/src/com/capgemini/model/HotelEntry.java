package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="hoteldetails")
public class HotelEntry {
	
	@Id
	private int hotelId;
	
	private String hotelName;
	private String hotelRating;
	private int rate;
	private int availableRooms;
	public HotelEntry() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelRating() {
		return hotelRating;
	}
	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	public HotelEntry(int hotelId, String hotelName, String hotelRating, int rate, int availableRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.rate = rate;
		this.availableRooms = availableRooms;
	}
	@Override
	public String toString() {
		return "HotelEntity [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating
				+ ", rate=" + rate + ", availableRooms=" + availableRooms + "]";
	}

}
