package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IBookingDAO;
import com.capgemini.model.HotelEntry;


@Service
public class BookingServiceImpl implements IBookingService {
	
	@Autowired
	private IBookingDAO iBookingDAO;

	@Override
	public List<HotelEntry> viewAllHotelDetails() {
		// TODO Auto-generated method stub
		List<HotelEntry> hotelDetails = iBookingDAO.viewAllHotelDetails();
		return hotelDetails;
	}

}
