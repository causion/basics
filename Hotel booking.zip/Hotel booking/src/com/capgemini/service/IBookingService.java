package com.capgemini.service;

import java.util.List;

import com.capgemini.model.HotelEntry;


public interface IBookingService {
	
	public List<HotelEntry> viewAllHotelDetails();

}
