package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Domain;
import com.cg.model.Trainee;
import com.cg.service.TraineeService;


@Controller
public class TraineeController {
	
	@Autowired
	Trainee trainee;
	
	@Autowired
	TraineeService traineeService;
	
	
	@RequestMapping("/")
	public String loginPage()
	{
		return "login";
	}
	
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public ModelAndView loginValidation(@RequestParam String username,@RequestParam String password){
		ModelAndView modelAndView = new ModelAndView();
		if(username.equals("jaswanth") && password.equals("jaswanth")){
			modelAndView.setViewName("TraineeManagementSystem");
		}
		else{
			modelAndView.addObject("status", "Invalid login");
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}
	
	@ModelAttribute("domainlist")
	public List<Domain> populate(){
		List<Domain> domainlist=new ArrayList<>();
		Domain d1=new Domain();
		d1.setName("JEE");
		Domain d2=new Domain();
		d2.setName(".NET");
		Domain d3=new Domain();
		d3.setName("Mainframe");
		domainlist.add(d1);
		domainlist.add(d2);
		domainlist.add(d3);
		return domainlist;
	}

	
	@RequestMapping("/addtrainee")
	public String addProfile(Model model) {
		model.addAttribute(trainee);
		return "add";		
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ModelAndView register(@Valid Trainee trainee,BindingResult result) {
		ModelAndView modelView=new ModelAndView();	
		if(result.hasErrors()) {
			modelView.setViewName("add");
			modelView.addObject("status","Couldn't insert");
			
		}
		else {
			traineeService.add(trainee);
			modelView.setViewName("login");
			modelView.addObject("status","updated successfully...");
		}
		return modelView;
	}
	
	
	
	@RequestMapping("/modify")
	public String modify() {
		return "modify";
	}
	
	@RequestMapping(value="/modifyconfirm",method=RequestMethod.POST)
	public ModelAndView modifyConfirm(@RequestParam Integer traineeId){
		ModelAndView modelAndView = new ModelAndView();
		Trainee trainee = traineeService.retrieveById(traineeId);
		if(trainee != null) {
			modelAndView.addObject("trainee", trainee);
			modelAndView.setViewName("modify");
		}
		else {
			modelAndView.addObject("status", "Invalid Trainee ID");
		}
		return modelAndView;
		
	}
	
	
	@RequestMapping ("/delete")
	public String deleteById(@RequestParam Integer traineeId) {
		traineeService.delete(traineeId);
		return "delete";
	}
	
	@RequestMapping("/retrieveall")
	public ModelAndView viewAll() {
		ModelAndView modelAndView=new ModelAndView();	
		List<Trainee> traineelist=traineeService.retrieveAllTrainee();
		modelAndView.addObject("traineelist",traineelist);
		modelAndView.setViewName("viewall");
		return modelAndView;		
	}
	
	
	@RequestMapping("/retrieve")
	public ModelAndView search(@RequestParam Integer traineeId) {	

		Trainee trainee=traineeService.retrieveById(traineeId);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("trainee", trainee);
		if(trainee==null) {
			modelAndView.addObject("status", "Trainee Id is invalid");
		}
		modelAndView.setViewName("retrieve");
		return modelAndView;
	}	
	
}
