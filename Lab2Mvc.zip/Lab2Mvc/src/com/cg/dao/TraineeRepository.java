package com.cg.dao;

import java.util.List;

import com.cg.model.Trainee;

public interface TraineeRepository {
	
	public Trainee add(Trainee trainee);
	public boolean delete(int traineeId);
	public void modify(Trainee trainee);
	public Trainee retrieveById(int traineeId);
	public List<Trainee> retrieveAllTrainee();
	public Trainee validate(String username,String password);
	

}
