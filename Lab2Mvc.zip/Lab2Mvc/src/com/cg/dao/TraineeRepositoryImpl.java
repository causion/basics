package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.cg.model.Trainee;

@Repository
public class TraineeRepositoryImpl implements TraineeRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	@Override
	public Trainee add(Trainee trainee) {
		entityManager.persist(trainee);
		return trainee;
	}

	@Override
	public boolean delete(int traineeId) {
		// TODO Auto-generated method stub
		Trainee trainee=entityManager.find(Trainee.class, traineeId);
		entityManager.remove(trainee);
		return true;
	}

	@Override
	public void modify(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.merge(trainee);

	}

	@Override
	public Trainee retrieveById(int traineeId) {
		// TODO Auto-generated method stub
		Trainee trainee = null;
		try {
			trainee = entityManager.find(Trainee.class, traineeId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainee;
	}

	@Override
	public List<Trainee> retrieveAllTrainee() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee",Trainee.class);
		List<Trainee> traineelist=query.getResultList();	
		return traineelist;
	}

	@Override
	public Trainee validate(String username, String password) {
		// TODO Auto-generated method stub
		Trainee trainee = null;
		try {
			TypedQuery<Trainee> query=entityManager.createQuery(
					"select c from Trainee c where c.username=?1 and c.password=?2"
					,Trainee.class);
			query.setParameter(1, username);
			query.setParameter(2, password);
			query.setMaxResults(1);
			trainee = query.getSingleResult();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainee;
	}

}
