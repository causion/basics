package com.cg.model;

public class Domain {


		private String name;
		
		public Domain() {
			
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
}


