package com.cg.service;

import java.util.List;

import com.cg.model.Trainee;

public interface TraineeService {
	public boolean add(Trainee trainee);
	public boolean modify(Trainee trainee);
	public boolean delete(int traineeId);
	public Trainee retrieveById(int traineeId);
	public List<Trainee> retrieveAllTrainee();

}
