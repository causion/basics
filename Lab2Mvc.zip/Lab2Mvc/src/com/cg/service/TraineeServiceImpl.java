package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TraineeRepository;
import com.cg.model.Trainee;
@Service
public class TraineeServiceImpl implements TraineeService {
	
	@Autowired
	TraineeRepository traineeRepository;
	

	@Override
	public boolean add(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeRepository.add(trainee);
		return true;
	}

	@Override
	public boolean modify(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeRepository.modify(trainee);
		return true;
	}

	@Override
	public boolean delete(int traineeId) {
		// TODO Auto-generated method stub
		traineeRepository.delete(traineeId);
		return true;
	}

	@Override
	public Trainee retrieveById(int traineeId) {
		// TODO Auto-generated method stub
		return traineeRepository.retrieveById(traineeId);

	}

	@Override
	public List<Trainee> retrieveAllTrainee() {
		// TODO Auto-generated method stub
		return traineeRepository.retrieveAllTrainee();
	}

}
