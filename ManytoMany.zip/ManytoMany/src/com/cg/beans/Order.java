package com.cg.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ordermany")
public class Order implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator="seq1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="seq1",sequenceName="ordermanyseq",initialValue=1000,allocationSize=1)
	private int id;
	@Temporal(TemporalType.DATE)
	private Date orderdate;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="productorder",
	joinColumns= {@JoinColumn(name="orderid")},
	inverseJoinColumns= {@JoinColumn(name="productid")}
	)
	private Set<Product> products=new HashSet<>();
	
	public Order() {
		
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	public void addproduct(Product p) {
		this.getProducts().add(p);
	}
	

}
