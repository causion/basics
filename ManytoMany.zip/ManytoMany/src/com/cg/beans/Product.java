package com.cg.beans;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="productmany")
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator="seq2",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="seq2",sequenceName="productmanyseq",initialValue=100,allocationSize=1)
	private int id;
	private String name;
	private double price;
	@ManyToMany(cascade=CascadeType.ALL,mappedBy="products")
	private Set<Order> orders=new HashSet<>();
	public Product() {
		
		// TODO Auto-generated constructor stub
	}
	public Product(String name, double price, Set<Order> orders) {
		super();
		this.name = name;
		this.price = price;
		this.orders = orders;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Set<Order> getOrders() {
		return orders;
	}
	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}
	
	

}
