package com.cg.client;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Order;
import com.cg.beans.Product;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		Product p1=new Product();
		p1.setName("watch");
		p1.setPrice(66889);
		
		
		Product p2=new Product();
		p2.setName("pen");
		p2.setPrice(8899);
		
		
		Product p3=new Product();
		p3.setName("mobile");
		p3.setPrice(99999);
		
		//first order
		Order jaswanthorder=new Order();
		jaswanthorder.setOrderdate(new Date());
		jaswanthorder.addproduct(p1);
		jaswanthorder.addproduct(p3);
		
		
		//second order
				Order kannaorder=new Order();
				kannaorder.setOrderdate(new Date());
				kannaorder.addproduct(p1);
				kannaorder.addproduct(p2);
				manager.persist(jaswanthorder);
				manager.persist(kannaorder);
				transaction.commit();
				System.out.println("Object saved");

	}

}
