package com.cg.client;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Department;
import com.cg.beans.Employee;

public class OneToManyClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		Employee e1=new Employee("jaswanth",66666);
		Employee e2=new Employee("kanna",88888);
		Employee e3=new Employee("gj",66688);
		Set<Employee> employees=new HashSet<>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		Department d1=new Department();
		d1.setName("training");	
		e1.setDepartment(d1);
		e2.setDepartment(d1);
		e3.setDepartment(d1);	
		d1.setEmployees(employees);
		manager.persist(d1);
		transaction.commit();
		System.out.println("Objects saved");

	}

}
