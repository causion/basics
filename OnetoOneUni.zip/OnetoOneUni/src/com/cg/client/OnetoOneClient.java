package com.cg.client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Address;
import com.cg.beans.Student;

public class OnetoOneClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		Address address=new Address("#25 8th cross,SRNagar", "bangalore",560027);
		Student student=new Student();
		student.setName("jaswanth");
		student.setAddress(address);
		manager.persist(student);
		transaction.commit();
		System.out.println("Objects saved");
		
	}

}
