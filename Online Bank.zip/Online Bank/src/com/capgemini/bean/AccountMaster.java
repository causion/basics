package com.capgemini.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Component;

@Entity
@Component
public class AccountMaster {
	
	@Id
	@GeneratedValue(generator="cust",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust",sequenceName="custseq",initialValue=1000,allocationSize=1)
	@Column(length=15)
	private String accountNumber;
	@NotBlank(message="The account type should be selected")
	private String accountType;
	
	private double accountBalance;
	
	private Date openDate;
	
	private double interestRate;
	
	@NotBlank(message="Account holder name should not be empty")
	@Pattern(regexp="^[A-Za-z]",message="Account holder name should be match with pattern")
	@Column(length=20)
	private String accountHolderName;
	
	@NotBlank(message="must enter email")
	@Email(message="Invalid email id")
	@Column(length=25)
	private String email;
	
	@NotBlank(message="Address  should not be empty")
	@Column(length=20)
	private String address;
	
	@NotBlank(message="Pan number should not be empty")
	@Pattern(regexp="^[A-Za-z]{5,20}$",message="Pan number should be match with pattern")
	@Column(length=20)
	private String panNumber;

	public AccountMaster() {
		
	}

	public AccountMaster(String accountNumber, String accountType, double accountBalance, Date openDate,
			double interestRate, String accountHolderName, String email, String address, String panNumber) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.openDate = openDate;
		this.interestRate = interestRate;
		this.accountHolderName = accountHolderName;
		this.email = email;
		this.address = address;
		this.panNumber = panNumber;
	}

	@Override
	public String toString() {
		return "AccountMaster [accountNumber=" + accountNumber + ", accountType=" + accountType + ", accountBalance="
				+ accountBalance + ", openDate=" + openDate + ", interestRate=" + interestRate + ", accountHolderName="
				+ accountHolderName + ", email=" + email + ", address=" + address + ", panNumber=" + panNumber + "]";
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	

}
