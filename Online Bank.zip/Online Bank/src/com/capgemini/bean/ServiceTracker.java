package com.capgemini.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="service_tracker")
public class ServiceTracker {
	
	@Id
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="seq",sequenceName="service_id_seq",initialValue=100,allocationSize=1)
	private int serviceId;
	private String serviceDescription;
	private String accountNumber;
	private Date serviceRaisedDate;
	private String serviceStatus;
	public ServiceTracker() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	@Override
	public String toString() {
		return "ServiceTracker [serviceId=" + serviceId + ", serviceDescription=" + serviceDescription
				+ ", accountNumber=" + accountNumber + ", serviceRaisedDate=" + serviceRaisedDate + ", serviceStatus="
				+ serviceStatus + "]";
	}
	
	
}
