package com.capgemini.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.ServiceTracker;
import com.capgemini.exception.BankException;
import com.capgemini.service.BankService;


@CrossOrigin(origins="http://localhost:8081")
@RestController
public class ServiceController {
	
	@Autowired
	BankService bankService;
	
	
	@RequestMapping(value="/service",method=RequestMethod.GET)
	public List<ServiceTracker> trackService(ServiceTracker serviceTracker){
		System.out.println("controller-all");
		List<ServiceTracker> servlist = null;
		try {
			servlist = bankService.trackService(serviceTracker);
		} catch (BankException e) {
			e.printStackTrace();
		}
	return servlist;
	}
	
	
	@RequestMapping(value="/requestchequebook",method=RequestMethod.POST)
	public void requestChequeBook(@RequestBody ServiceTracker serviceTracker) throws BankException{
		bankService.requestChequeBook(serviceTracker);		
	}
	


}
