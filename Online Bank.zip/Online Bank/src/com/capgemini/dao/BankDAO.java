package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.ServiceTracker;
import com.capgemini.exception.BankException;

public interface BankDAO {
	
	public int requestChequeBook(ServiceTracker serviceTracker) throws BankException;
	
	public List<ServiceTracker> trackService(ServiceTracker serviceTracker) throws BankException;
	
	public int getServiceId();

	
}
