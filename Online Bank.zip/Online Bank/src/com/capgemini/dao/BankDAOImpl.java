package com.capgemini.dao;


import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bean.ServiceTracker;
import com.capgemini.exception.BankException;

@Repository
public class BankDAOImpl implements BankDAO {
	Logger logger = Logger.getLogger(BankDAOImpl.class);
	
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	@Override
	public int requestChequeBook(ServiceTracker serviceTracker) throws BankException {
		logger.info("Inside requestChequeBook DAO");
		entityManager.persist(serviceTracker);
		return getServiceId();
		
	}

	

	@Override
	public List<ServiceTracker> trackService(ServiceTracker serviceTracker) throws BankException {
		// TODO Auto-generated method stub
		TypedQuery<ServiceTracker> query=entityManager.createQuery("from ServiceTracker",ServiceTracker.class);
		List<ServiceTracker> servlist=query.getResultList();
		System.out.println(servlist);
		return servlist;
	}



	@Override
	public int getServiceId() {
		TypedQuery<ServiceTracker> query=entityManager.createQuery("SELECT service_id_seq.CURRVAL FROM DUAL",ServiceTracker.class);
		int serviceId = query.getFirstResult();
		return serviceId;
	}

}
