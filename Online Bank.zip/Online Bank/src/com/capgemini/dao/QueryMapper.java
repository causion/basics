package com.capgemini.dao;

public interface QueryMapper {
	
	static String INSERT_SERVICE_TRACKER = "INSERT INTO service_tracker VALUES(service_req_seq.nextval,?,?,sysdate,'InProgress')";
    
	static String GET_SERVICE_DETAILS = "select * from service_tracker where (accountnumber = ? or serviceid =?)";
}
