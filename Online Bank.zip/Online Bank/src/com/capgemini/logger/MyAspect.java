package com.capgemini.logger;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {

	Log log=LogFactory.getLog(getClass());
	public MyAspect() {
		System.out.println("Constructor");
	}
	@Before("execution(* com.*.*(..))")
	public void beforem(JoinPoint jp) {
		log.info("Log registered\n");
		log.info(jp.getSignature().getName() +" is started\n");
		}
	@AfterReturning(value="execution(* com.*.*(..))",returning="rtval")
	public void afterr(Object rtval) {
		log.info("Return value is : "+rtval);
		}
	@After("execution(* com.*.*(..))")
	public void afterm(JoinPoint jp) {
		log.info(jp.getSignature().getName() +" Ended\n");
		}
	@AfterThrowing(value="execution(* com.*.*(..))",throwing="ex")
	public void aftert(Exception ex) {
		log.info(ex+" is occured");
		}
	
	@Around(value="execution(* com.*.*(..))")
	public void aroundm(ProceedingJoinPoint jp) {
		log.info("=================== Around started ===============\n");
		log.info(jp.getSignature().getName());
		log.info("Arguments are :"+Arrays.toString(jp.getArgs()));
		try {
			jp.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("=============== Around Ended======================");
		}
}
