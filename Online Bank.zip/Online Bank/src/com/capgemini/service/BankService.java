package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.ServiceTracker;
import com.capgemini.exception.BankException;

public interface BankService {
	
	public boolean requestChequeBook(ServiceTracker serviceTracker) throws BankException;
	public List<ServiceTracker> trackService(ServiceTracker serviceTracker) throws BankException;
	public int getServiceId();
}
