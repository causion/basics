package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.ServiceTracker;
import com.capgemini.dao.BankDAO;
import com.capgemini.exception.BankException;

@Service
public class BankServiceImpl implements BankService {
	
	@Autowired
	BankDAO bankDAO;

	@Override
	public boolean requestChequeBook(ServiceTracker serviceTracker) throws BankException {
		// TODO Auto-generated method stub
		bankDAO.requestChequeBook(serviceTracker);
		return true;
	}

	@Override
	public List<ServiceTracker> trackService(ServiceTracker serviceTracker) throws BankException {
		// TODO Auto-generated method stub
		return bankDAO.trackService(serviceTracker);
	}

	@Override
	public int getServiceId() {
		// TODO Auto-generated method stub
		return bankDAO.getServiceId();
	}

	
}
