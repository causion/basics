package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.beans.Admin;
import com.capgemini.beans.Payee;
import com.capgemini.beans.ServiceRequest;
import com.capgemini.beans.Transaction;
import com.capgemini.beans.User;
import com.capgemini.exception.BankingException;
import com.capgemini.service.IBankingService;

@Controller
public class BankingController {

	ArrayList<String> typeList;
	@Autowired
	IBankingService bankingService;

	User user = null;

	@RequestMapping("/")
	public String homePage() {
		return "index";
	}

	@RequestMapping("/adminHomePage")
	public String adminHomePage() {
		return "AdminHomePage";
	}

	@RequestMapping("/userHomePage")
	public ModelAndView UserHomePage() {
		ModelAndView modelView = null;
		if (user != null) {
			modelView = new ModelAndView("UserHomePage");
			modelView.addObject("customerName", user.getCustomerName());
		} else {
			modelView = new ModelAndView("UserHomePage");
		}
		return modelView;
	}

	@RequestMapping("/LoginUserForm")
	public ModelAndView getUserHomePage() {
		user = null;
		return new ModelAndView("LoginUserForm", "user", new User());
	}

	@RequestMapping(value = "/LoginUserCheck", params = "forgot")
	public ModelAndView ForgotPassword(
			@ModelAttribute("user") @Valid User userLogin,
			BindingResult result) {

		return new ModelAndView("ForgotPasswordPage", "user", userLogin);

	}

	@RequestMapping(value = "/ForgotPasswordCheck")
	public ModelAndView checkUsernamePassword(@RequestParam String ans,
			@RequestParam String username, @ModelAttribute("user") User user) {
		ModelAndView modelView = new ModelAndView();
		try {
			if (bankingService.checkSecurity(ans, username)) {
				modelView.setViewName("changeForgotPassword");
				modelView.addObject("user", user);
			} else {
				modelView = new ModelAndView("LoginUserForm", "user", new User());
				modelView.addObject("errmsg", "Wrong security answer");
				return modelView;
			}
		} catch (BankingException e) {

		}
		return modelView;

	}

	@RequestMapping(value = "/LoginUserCheck", params = "login")
	public ModelAndView UserHomePage(
			@ModelAttribute("user") @Valid User userLogin,
			BindingResult result, HttpServletRequest request) {
		ModelAndView modelView = null;

		try {
			HttpSession session = request.getSession();
			user = bankingService.checkUserCredentials(userLogin.getUsername(),
					userLogin.getPassword());

			if (user != null && user.getAccStatus().equals("active")) {
				modelView = new ModelAndView("UserHomePage");
				modelView.addObject("customerName", user.getCustomerName());
				Object blockValue = session.getAttribute(userLogin
						.getUsername());
				if (blockValue != null) {
					session.setAttribute(userLogin.getUsername(), null);
				}

			} else {
				modelView = new ModelAndView("LoginUserForm", "user", user);
				if (user != null && user.getAccStatus().equals("block")) {
					modelView.addObject("status", false);
					modelView.addObject("flag", false);
				} else {

					Object str = session.getAttribute(userLogin.getUsername());
					if (str == null) {
						session.setAttribute(userLogin.getUsername(), 1);

					} else {
						int val = (int) session.getAttribute(userLogin
								.getUsername());
						val++;
						session.setAttribute(userLogin.getUsername(), val);

					}
					if ((int) session.getAttribute(userLogin.getUsername()) == 3) {
						bankingService.blockUser(userLogin.getUsername());
						modelView.addObject("status", false);
					}
					modelView.addObject("flag", true);
				}

			}

		} catch (BankingException e) {
			e.printStackTrace();

		}

		return modelView;

	}

	@RequestMapping("/userViewMiniStatement")
	public String userViewMiniStatement() {
		return "miniStatement";
	}

	@RequestMapping("/miniStatement")
	public ModelAndView miniStatement() {

		ModelAndView modelView = null;

		try {

			List<Transaction> transactionList = bankingService
					.getMiniStatement(user.getUsername());
			if (!transactionList.isEmpty()) {

				modelView = new ModelAndView("miniStatement");
				modelView.addObject("flag", "true");
				modelView.addObject("transactionList", transactionList);

			} else {
				modelView = new ModelAndView("miniStatement");
				modelView.addObject("errmsg", "No transaction available!!!");
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("miniStatement");
			modelView.addObject("errmsg", "No transaction available!!!");
		}

		return modelView;
	}

	@RequestMapping("/detailedStatement")
	public ModelAndView detailedStatement() {
		return new ModelAndView("miniStatement", "check", "true");
	}

	@RequestMapping("/finalDetailedStatement")
	public ModelAndView finalDetailedStatement(@RequestParam String startDate,
			@RequestParam String endDate) {

		ModelAndView modelView = null;

		try {
			List<Transaction> transactionList = bankingService
					.getDetailedStatement(startDate, endDate,
							user.getAccountId());
			if (!transactionList.isEmpty()) {
				modelView = new ModelAndView("miniStatement");
				modelView.addObject("flag", "true");
				modelView.addObject("transactionList", transactionList);

			} else {
				modelView = new ModelAndView("miniStatement");
				modelView.addObject("errmsg", "No transaction available!!!");
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("miniStatement");
			modelView.addObject("errmsg", "No transaction available!!!");
		}

		return modelView;
	}

	@RequestMapping("/userChangeDetails")
	public ModelAndView changeDetails() {

		return new ModelAndView("changeUserDetails", "newUser", user);

	}

	@RequestMapping("/update")
	public ModelAndView updateDetails(
			@ModelAttribute("newUser") @Valid User newUser,
			BindingResult result) {

		ModelAndView modelView = null;

		try {
			if (!result.hasErrors()) {
				user = bankingService.changeUserDetails(newUser.getAddress(),
						newUser.getPhoneNo(), user.getAccountId());
				if (user != null) {
					modelView = new ModelAndView("changeUserDetails", "newUser", user);
					modelView.addObject("flag", true);

				} else {
					modelView = new ModelAndView("changeUserDetails", "newUser", user);
					modelView.addObject("errmsg", "User not added internal error!!!");

				}
			} else {
				modelView = new ModelAndView("changeUserDetails", "newUser", newUser);
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("changeUserDetails", "newUser", user);
			modelView.addObject("errmsg", "User not added internal error!!!");

		}

		return modelView;

	}

	@RequestMapping("/userChangePassword")
	public ModelAndView changePasswordPage() {
		User newUser = new User();
		newUser.setUsername(user.getUsername());
		return new ModelAndView("changePassword", "newUser", newUser);

	}

	@RequestMapping("/updatePassword")
	public ModelAndView updatePassword(@RequestParam String password,
			@RequestParam String newPassword1,
			@RequestParam String newPassword2, @RequestParam String username) {
		ModelAndView modelView = null;
		if (user == null || user.getPassword() == null) {
			if (newPassword1.equals(newPassword2)) {
				boolean flag = bankingService.changePasswordByUsername(
						newPassword2, username);
				if (flag) {
					modelView = new ModelAndView("LoginUserForm", "user",
							new User());
					modelView.addObject("password", true);
					return modelView;
				}
			} else {
				modelView = new ModelAndView("changeForgotPassword");
				modelView.addObject("errmsg", "Password did not match!!!");
				return modelView;
			}
		}
		if (user.getPassword().equals(password)) {
			if (newPassword1.equals(newPassword2)) {
				boolean flag = bankingService.changePasswordByUsername(newPassword2, username);
				if (flag) {
					modelView = new ModelAndView("changePassword");

					modelView.addObject("flag", true);

				} else {
					modelView = new ModelAndView("changePassword");
					modelView.addObject("errmsg",
							"New password should be different!!!");
				}
			} else {
				modelView = new ModelAndView("changePassword");
				modelView.addObject("errmsg", "Passwords did not match!!!");
			}
		} else {
			modelView = new ModelAndView("changePassword");
			modelView.addObject("errmsg",
					"Old Password is not correct,Please try again!!!");
		}

		return modelView;

	}

	@RequestMapping("/userFundTransfer")
	public ModelAndView userfundTransfer() {

		ModelAndView modelView = null;

		try {
			List<Payee> userList = new ArrayList<Payee>();
			userList = bankingService.getAllUser(user.getAccountId());
			modelView = new ModelAndView("fundTransferPage", "userList", userList);
		} catch (BankingException e) {

		}
		return modelView;
	}

	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam int accno,
			@RequestParam double amt) {

		ModelAndView modelView = null;
		List<Payee> userList = null;
		try {
			userList = new ArrayList<Payee>();
			userList = bankingService.getAllUser(user.getAccountId());
			if (accno == -1 || amt == 0) {
				modelView = new ModelAndView("fundTransferPage", "userList", userList);
				if(amt!=0)
					modelView.addObject("errmsg", "Please select a payee! ");
				else
					modelView.addObject("errmsg", "Amount can't be Zero!");
			} else {
				if (bankingService.fundSub(user.getAccountId(), amt)) {

					bankingService.fundTransfer(user.getAccountId(),accno, amt);

					modelView = new ModelAndView("fundTransferPage", "userList",
							userList);
					modelView.addObject("flag", true);
					modelView.addObject("msg", "Money transferred successfully!");

				} else {
					modelView = new ModelAndView("fundTransferPage", "userList",
							userList);
					modelView.addObject("errmsg",
							"Minimum Balance in the account should be One Thousand.");

				}
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("fundTransferPage");
			if(e.getMessage().equals("block")){
				modelView.addObject("errmsg", "The payee account is blocked!");
				modelView.addObject("userList",userList);
			}
			else{
				modelView.addObject("errmsg",
					"Something went wrong");
				modelView.addObject("userList",userList);
			}
		}
		return modelView;
	}

	@RequestMapping("/addPayee")
	public ModelAndView addPayee() {

		ModelAndView modelView = new ModelAndView("addPayee");
		return modelView;
	}

	@RequestMapping("/addPayeeDetails")
	public ModelAndView addPayeeDetails(@RequestParam int paccId,
			@RequestParam String pname) {

		ModelAndView modelView = null;

		try {
			Payee payee = new Payee();
			payee.setPayeeAccountId(paccId);
			payee.setPayeeName(pname);
			if (paccId != user.getAccountId()) {
				if (bankingService.checkPayee(paccId, user.getAccountId())) {
					payee.setAccountId(user.getAccountId());
					if (bankingService.addPayee(payee)) {
						modelView = new ModelAndView("addPayee");
						modelView.addObject("flag", true);
						modelView.addObject("msg",
								"Payee added successfully!");

					}

					else {
						modelView = new ModelAndView("addPayee");
						modelView.addObject("errmsg", "Payee not added");

					}
				} else {
					modelView = new ModelAndView("addPayee");
					modelView.addObject("errmsg",
							"No User available with this Payee Account Id");

				}
			} else {
				modelView = new ModelAndView("addPayee");
				modelView.addObject("errmsg", "User cannot add himself as payee");
			}
		} catch (BankingException e) {

			modelView = new ModelAndView("addPayee");
			modelView.addObject("errmsg",
					"No payee available with this Payee Account Id");
		}
		return modelView;
	}

	@RequestMapping("/userRequestChequeBook")
	public ModelAndView userRequestChequebook() {
		ModelAndView modelView = null;

		try {
			String serviceStatus = bankingService.getChequeBookStatus(user
					.getAccountId());

			if (serviceStatus != null) {
				if ("issued".equals(serviceStatus)) {
					modelView = new ModelAndView("userRequestChequeBookForm");
					modelView.addObject("check", "nDisplay");
					modelView.addObject("errmsg",
							"Cheque book has been issued already!!!");
				} else if ("dispatched".equals(serviceStatus)) {
					modelView = new ModelAndView("userRequestChequeBookForm");
					modelView.addObject("check", "nDisplay");
					modelView.addObject("errmsg",
							"Cheque book has been dispatched and it will reach within 3 working days!!!");
				} else if ("not issued".equals(serviceStatus)) {

					modelView = new ModelAndView("userRequestChequeBookForm");
					modelView.addObject("check", "display");
				} else if ("open".equals(serviceStatus)) {
					modelView = new ModelAndView("userRequestChequeBookForm");
					modelView.addObject("check", "nDisplay");
					modelView.addObject("errmsg", "Your request is in process!!!");
				}

			} else {
				modelView = new ModelAndView("userRequestChequeBookForm");
				modelView.addObject("errmsg", "No data available!!!");

			}
		} catch (BankingException e) {
			modelView = new ModelAndView("userRequestChequeBookForm");
			modelView.addObject("errmsg", "internal error!!!");
		}
		return modelView;

	}

	@RequestMapping("/raiseRequestForChequeBook")
	public ModelAndView raiseRequestForChequeBook(
			@RequestParam String serviceDescription) {
		ModelAndView modelView = null;

		try {
			int serviceId = bankingService.raiseChequeBookRequest(
					user.getAccountId(), serviceDescription);

			if (serviceId != 0) {

				modelView = new ModelAndView("userRequestChequeBookForm");
				modelView.addObject("check", "display");
				modelView.addObject("flag", "true");
				modelView.addObject("serviceId", serviceId);

				// view = "view/userRequestChequeBookForm.jsp";

			} else {
				modelView = new ModelAndView("userRequestChequeBookForm");
				modelView.addObject("errmsg", "No data available!!!");
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("userRequestChequeBookForm");
			modelView.addObject("errmsg", "internal error!!!");
		}
		return modelView;

	}

	@RequestMapping("/userTrackServiceRequestForm")
	public String userTrackServiceRequestForm() {
		return "userTrackServiceRequestForm";
	}

	@RequestMapping("/userTrackServiceRequest")
	public ModelAndView userTrackServiceRequest(
			@RequestParam String serviceIdstr, @RequestParam String accountIdstr) {

		ModelAndView modelView = null;

		try {

			if (serviceIdstr.isEmpty() == false) {
				System.out.println(serviceIdstr);
				System.out.println(user.getAccountId());
				int serviceId = Integer.parseInt(serviceIdstr);
				ServiceRequest service = bankingService
						.checkServiceExist(user.getAccountId(), serviceId);

				if (service != null) {
					modelView = new ModelAndView("userTrackServiceRequestForm");
					modelView.addObject("flag", "2");
					List<ServiceRequest> serviceList = new ArrayList<ServiceRequest>();
					serviceList.add(service);
					modelView.addObject("serviceList", serviceList);

				} else {

					modelView = new ModelAndView("userTrackServiceRequestForm");
					modelView.addObject("errmsg",
							"Request Service Id does not exit!!!");

				}
			} else if (serviceIdstr.isEmpty() == true) {
				int accountId = Integer.parseInt(accountIdstr);
				List<ServiceRequest> serviceList = bankingService
						.checkServiceExistAcc(user.getAccountId(), accountId);

				if (!serviceList.isEmpty()) {
					
					modelView = new ModelAndView("userTrackServiceRequestForm");
					modelView.addObject("flag", "2");
					modelView.addObject("serviceList", serviceList);

				} else {

					modelView = new ModelAndView("userTrackServiceRequestForm");
					modelView.addObject("errmsg",
							"Entered Account Id does not exit!!!");

				}
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("userTrackServiceRequestForm");
			modelView.addObject("errmsg", "internal error!!!");
		}
		return modelView;
	}

	@RequestMapping("/LoginAdmin")
	public ModelAndView getAdminHomePage() {
		Admin admin = new Admin();

		return new ModelAndView("LoginAdminForm", "admin", admin);
	}

	@RequestMapping("/LoginAdminCheck")
	public ModelAndView AdminHomePage(
			@ModelAttribute("admin") @Valid Admin admin,
			BindingResult result) {
		ModelAndView modelView = null;

		try {

			if (bankingService.checkAdminCredentials(admin)) {
				modelView = new ModelAndView("AdminHomePage");
			} else {
				modelView = new ModelAndView("LoginAdminForm", "admin", admin);
				modelView.addObject("flag", true);
			}

		} catch (BankingException e) {
			modelView = new ModelAndView("LoginAdminForm", "admin", admin);
			modelView.addObject("flag", true);

		}

		return modelView;

	}

	@RequestMapping("/createNewAccountForm")
	public String createNewUserPage(Model model) {
		User newUser = new User();
		typeList = new ArrayList<String>();

		typeList.add("Savings Account");
		typeList.add("Current Account");

		model.addAttribute("typeList", typeList);
		model.addAttribute("newUser", newUser);

		return "createNewAccountForm";
	}

	@RequestMapping("/createNewAccount")
	public ModelAndView addNewUserPage(
			@ModelAttribute("newUser") @Valid User newUser,
			BindingResult result) {
		ModelAndView modelView = null;

		try {
			if (!result.hasErrors()) {
				newUser.setAccStatus("active");
				int accId = bankingService.addUser(newUser);
				if (accId != -1 && accId != 0) {
					modelView = new ModelAndView("createNewAccountForm", "newUser",
							new User());
					modelView.addObject("accId", accId);
					modelView.addObject("flag", true);
					typeList = new ArrayList<String>();
					typeList.add("Savings Account");
					typeList.add("Current Account");
					modelView.addObject("typeList", typeList);

				} else if (accId == -1) {
					modelView = new ModelAndView("createNewAccountForm", "newUser",
							newUser);
					typeList = new ArrayList<String>();
					typeList.add("Savings Account");
					typeList.add("Current Account");
					modelView.addObject("typeList", typeList);
					modelView.addObject(
							"errmsg",
							"Username already exists! Please provide correct info or select another username");
				}
				else if(accId == 0){
					modelView = new ModelAndView("createNewAccountForm", "newUser",newUser);
					typeList = new ArrayList<String>();
					typeList.add("Savings Account");
					typeList.add("Current Account");
					modelView.addObject("typeList", typeList);
					modelView.addObject(
							"errmsg",
							"You can't open same type of account twice");
				}
			} else {
				modelView = new ModelAndView("createNewAccountForm", "newUser",
						newUser);
				typeList = new ArrayList<String>();
				typeList.add("Savings Account");
				typeList.add("Current Account");
				modelView.addObject("typeList", typeList);
			}

		} catch (BankingException e) {
			modelView = new ModelAndView("createNewAccountForm", "newUser", newUser);
			modelView.addObject("errmsg", e.getMessage());

		}

		return modelView;

	}

	@RequestMapping("/viewAllTransactionDetails")
	public String viewTransctionDetails() {
		return "transactionDetails";
	}

	@RequestMapping("/transactionDetails")
	public ModelAndView displayTransctionDetails(
			@RequestParam String startDate1, @RequestParam String endDate1) {

		ModelAndView modelView = null;

		try {
			List<Transaction> transactionDetails = bankingService.getAllTransactions(startDate1, endDate1);
			if (!transactionDetails.isEmpty()) {

				modelView = new ModelAndView("transactionDetails");
				modelView.addObject("flag", "true");
				modelView.addObject("transactionDetails", transactionDetails);

			} else {
				modelView = new ModelAndView("transactionDetails");
				modelView.addObject("errmsg", "No transaction available!!!");
			}
		} catch (BankingException e) {
			modelView = new ModelAndView("transactionDetails");
			modelView.addObject("errmsg", "No transaction available!!!");
		}

		return modelView;
	}

	@RequestMapping("/logout")
	public ModelAndView  logout() {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("status","Logged out successfully");
		modelAndView.setViewName("index");
		return modelAndView;
	}
	
	@RequestMapping("/adminback")
	public String adminBack() {
		return "AdminHomePage";
	}
	
	@RequestMapping("/userback")
	public String userBack() {
		return "UserHomePage";
	}
	
	@RequestMapping("/updateServiceRequestPage")
	public String updateServiceRequestPage() {
		return "updateServiceRequest";
	}
	
	@RequestMapping("/updateServiceRequest")
	public ModelAndView updateServiceRequest(@RequestParam Integer serviceId) throws BankingException {
		ModelAndView modelAndView = new ModelAndView();
		ServiceRequest serviceRequest = new ServiceRequest();
		serviceRequest = bankingService.getByServiceID(serviceId);
		if(serviceRequest != null) {
			if(serviceRequest.getServiceStatus().equals("Dispatched")) {
				modelAndView.setViewName("updateServiceRequest");
				modelAndView.addObject("serviceRequest", serviceRequest);
				modelAndView.addObject("status", "Status already updated");
				return modelAndView;
			}else {
				serviceRequest.setServiceStatus("Dispatched");
				bankingService.updateServiceRequest(serviceRequest);
				modelAndView.setViewName("updateServiceRequest");
				modelAndView.addObject("serviceRequest", serviceRequest);
				modelAndView.addObject("status", "Updated successfully!");
				return modelAndView;
			}
		}else {
			modelAndView.addObject("error", "Service ID does not exist");
			modelAndView.setViewName("updateServiceRequest");
			return modelAndView;
		}
		
		
	}
}
