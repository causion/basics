package com.capgemini.dao;

import java.util.List;

import com.capgemini.beans.Admin;
import com.capgemini.beans.Payee;
import com.capgemini.beans.ServiceRequest;
import com.capgemini.beans.User;
import com.capgemini.beans.Transaction;
import com.capgemini.exception.BankingException;

public interface IBankingDAO {

	public User checkUserCredentials(String username, String password) throws BankingException;

	public boolean blockUser(String username) throws BankingException;

	public String getChequeBookStatus(int accountNumber) throws BankingException;

	public int raiseChequeBookRequest(int accountId, String serviceDescription) throws BankingException;

	public ServiceRequest checkServiceExist(int accountId, int serviceId) throws BankingException;

	public List<Transaction> getMiniStatement(String username) throws BankingException;

	public List<Transaction> getDetailedStatement(String startDate, String endDate, int accountId)
			throws BankingException;

	public User changeUserDetails(String address, String phoneNo, int accountId) throws BankingException;

	public boolean changePassword(String password, int accId) throws BankingException;

	public List<Payee> getAllUser(int accountId) throws BankingException;

	public boolean fundTransfer(int sourceAcNo, int destAcNo, double amount) throws BankingException;

	public boolean fundSub(int accountId, double amount) throws BankingException;

	public boolean addPayee(Payee payee) throws BankingException;

	public boolean checkPayee(int paccId, int accId) throws BankingException;

	public boolean checkAdminCredentials(Admin admin) throws BankingException;

	public int addUser(User user) throws BankingException;

	public List<ServiceRequest> checkServiceExistAcc(int accountId1, int accountId2) throws BankingException;

	public List<Transaction> getAllTransactions(String startDate1, String endDate1) throws BankingException;

	public boolean checkSecurity(String ans, String username) throws BankingException;

	public boolean changePasswordByUsername(String newPassword2, String username);

	public void updateServiceRequest(ServiceRequest serviceRequest) throws BankingException;

	public String getServiceStatus(int serviceId) throws BankingException;

	public List<ServiceRequest> showAllServiceRequests(int accountId) throws BankingException;
	
	public ServiceRequest getByServiceID(int serviceId) throws BankingException;
}
