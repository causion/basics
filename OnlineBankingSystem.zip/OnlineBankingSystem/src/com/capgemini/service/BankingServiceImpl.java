package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IBankingDAO;
import com.capgemini.beans.Admin;
import com.capgemini.beans.Payee;
import com.capgemini.beans.ServiceRequest;
import com.capgemini.beans.Transaction;
import com.capgemini.beans.User;
import com.capgemini.exception.BankingException;

@Service
@Transactional
public class BankingServiceImpl implements IBankingService{

	@Autowired
	IBankingDAO bankingDao;

	public IBankingDAO getDao() {
		return bankingDao;
	}

	public void setDao(IBankingDAO bankingDao) {
		this.bankingDao = bankingDao;
	}

	@Override
	public User checkUserCredentials(String username, String password)
			throws BankingException {

		return bankingDao.checkUserCredentials(username, password);
	}

	@Override
	public boolean checkAdminCredentials(Admin admin)
			throws BankingException {

		return bankingDao.checkAdminCredentials(admin);
	}

	@Override
	public List<Transaction> getMiniStatement(String username)
			throws BankingException {

		return bankingDao.getMiniStatement(username);
	}

	@Override
	public List<Transaction> getDetailedStatement(String startDate,
			String endDate, int accountId) throws BankingException {
		return bankingDao.getDetailedStatement(startDate, endDate, accountId);
	}

	@Override
	public String getChequeBookStatus(int accountNumber)
			throws BankingException {
		return bankingDao.getChequeBookStatus(accountNumber);
	}

	@Override
	public int raiseChequeBookRequest(int accountId, String serviceDescription)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.raiseChequeBookRequest(accountId, serviceDescription);
	}

	@Override
	public ServiceRequest checkServiceExist(int accountId ,int serviceId)
			throws BankingException {
		// TODO Auto-generated method stub

		return bankingDao.checkServiceExist(accountId, serviceId);
	}
	
	@Override
	public List<ServiceRequest> checkServiceExistAcc(int accountId1, int accountId2) 
			throws BankingException {
		return bankingDao.checkServiceExistAcc(accountId1, accountId2);
	}

	@Override
	public User changeUserDetails(String address, String phoneNo,
			int accountId) throws BankingException {

		return bankingDao.changeUserDetails(address, phoneNo, accountId);
	}

	@Override
	public boolean changePassword(String password, int accountId)
			throws BankingException {

		return bankingDao.changePassword(password, accountId);
	}

	@Override
	public boolean fundTransfer(int sourceAcNo, int destAcNo, double amount)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.fundTransfer(sourceAcNo,destAcNo, amount);
	}

	@Override
	public List<Payee> getAllUser(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getAllUser(accountId);
	}

	@Override
	public boolean fundSub(int accountId, double amount)
			throws BankingException {
		return bankingDao.fundSub(accountId, amount);

	}

	@Override
	public boolean addPayee(Payee payee) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.addPayee(payee);
	}

	@Override
	public boolean checkPayee(int paccId, int accId) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.checkPayee(paccId, accId);
	}

	// admin services

	@Override
	public int addUser(User user) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.addUser(user);
	}

	@Override
	public List<Transaction> getAllTransactions(String startDate1,
			String endDate1) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getAllTransactions(startDate1, endDate1);
	}

	@Override
	public boolean blockUser(String username) throws BankingException {
		return bankingDao.blockUser(username);
	}

	@Override
	public boolean checkSecurity(String ans, String username)
			throws BankingException {
		return bankingDao.checkSecurity(ans, username);
	}

	@Override
	public boolean changePasswordByUsername(String newPassword2, String username) {
		return bankingDao.changePasswordByUsername(newPassword2, username);
	}

	@Override
	public void updateServiceRequest(ServiceRequest serviceRequest) throws BankingException {
		bankingDao.updateServiceRequest(serviceRequest);
		
	}

	@Override
	public String getServiceStatus(int serviceId) throws BankingException {
		return bankingDao.getServiceStatus(serviceId);
	}

	@Override
	public List<ServiceRequest> showAllServiceRequests(int accountId) throws BankingException {
		return bankingDao.showAllServiceRequests(accountId);
	}

	@Override
	public ServiceRequest getByServiceID(int serviceId) throws BankingException {
		return bankingDao.getByServiceID(serviceId);
	}
}
