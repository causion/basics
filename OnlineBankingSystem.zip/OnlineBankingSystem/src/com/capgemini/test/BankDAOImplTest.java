package com.capgemini.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.beans.Transaction;
import com.capgemini.beans.User;
import com.capgemini.dao.IBankingDAO;
import com.capgemini.exception.BankingException;


public class BankDAOImplTest {

	@Autowired
	IBankingDAO iBankDAO;
	
	@Autowired
	User user;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCheckUserCredentials() throws BankingException {
		assertEquals(21, iBankDAO.checkUserCredentials("Aishwarya", "Aishwarya@123").getAccountId());
        assertNotEquals(21, iBankDAO.checkUserCredentials("Aishwarya", "Aishwarya@123").getAccountId());
	}

	@Test
	public void testGetMiniStatement() throws BankingException{
		 List<Transaction> miniStatement = new ArrayList<>();
	        miniStatement = iBankDAO.getMiniStatement("Aishwarya");
	        assertTrue(miniStatement != null);
	}

	@Test
	public void testChangeUserDetails() throws BankingException {
        assertEquals("Bangalore", iBankDAO.changeUserDetails("Bangalore", "8978787878", 21).getAddress());
	}

}
