package com.cg.lms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;
import com.cg.lms.utility.JdbcUtility;

public class BookDaoImpl implements BookDAO {

	static Logger logger = Logger.getLogger(BookDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : addBookDetails argument : BookDetails class object return type
	 * : int author : Capgemini date : 14-02-2019
	 * 
	 * description : This method will take the model object as an argument and
	 * returns the generated id to the user
	 */

	@Override
	public int addBookDetails(BookDetails details) throws LMSException {

		int generatedId = 0;
		ResultSet resultSet = null;
		logger.info("in DAO impl class");
		logger.info("Book data is : " + details);

		connection = JdbcUtility.getConnection();
		logger.info("connection object created");

		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			logger.info("connection established..");

			statement.setString(1, details.getBookName());
			statement.setString(2, details.getAuthorName());
			statement.setDouble(3, details.getCost());
			statement.setDate(4, Date.valueOf(details.getPublishDate()));

			statement.executeUpdate();
			logger.info("statement executed, record inserted");

			statement = connection.prepareStatement(QueryMapper.selectGeneratedId);

			resultSet = statement.executeQuery();
			logger.info("resultset cretaed");

			resultSet.next();

			generatedId = resultSet.getInt(1);
			logger.info("generated id is: " + generatedId);

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LMSException("unable to create the statement");
		} finally {

			try {
				resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new LMSException("unable to close resultset object");
			}

			try {
				statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new LMSException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new LMSException("unable to close connection object");
			}
		}

		return generatedId;
	}

}
