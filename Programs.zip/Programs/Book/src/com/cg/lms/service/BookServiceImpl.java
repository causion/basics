package com.cg.lms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.lms.dao.BookDAO;
import com.cg.lms.dao.BookDaoImpl;
import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public class BookServiceImpl implements BookService {

	BookDAO bookDao = new BookDaoImpl();

	@Override
	public boolean validateBookDetails(BookDetails details) throws LMSException {

		boolean resultFlag = false;
		List<String> list = new ArrayList<>();

		if (validateBookName(details.getBookName()) == false) {
			list.add("Book First letter capital size in the range of 5 to 20 \n");
		}
		if (validateAuthorName(details.getAuthorName()) == false) {
			list.add("Author First letter capital size in the range of 5 to 20 \n");
		}
		if (validateBookCost(details.getCost()) == false) {
			list.add("cost should be greater than 5000");
		}

		if (list.size() > 0) {
			throw new LMSException(list + "");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	public boolean validateBookName(String name) {

		String nameRegEx = "[A-Z]{1}[A-Za-z ]{4,20}";
		return Pattern.matches(nameRegEx, name);
	}

	public boolean validateAuthorName(String name) {
		String authorRegEx = "[A-Z]{1}[A-Za-z ]{4,20}";
		return Pattern.matches(authorRegEx, name);
	}

	public boolean validateBookCost(Double cost) {

		boolean costFlag = true;

		if (cost < 5000) {
			costFlag = false;
		}
		return costFlag;
	}

	@Override
	public int addBook(BookDetails details) throws LMSException {
		return bookDao.addBookDetails(details);
	}

}
