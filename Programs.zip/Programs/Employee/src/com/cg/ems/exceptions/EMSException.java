package com.cg.ems.exceptions;

public class EMSException extends Exception {

	public EMSException(String message) {
		super(message);
	}
}
