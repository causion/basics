package com.cg.exceptions;

public class TestException extends Exception {

	public TestException(String message) {
		super(message);
	}
}
