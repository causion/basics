package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.exceptions.TestException;

public class JdbcOperations {

	Connection connection = null;
	Statement statement = null;

	public void createStudentTable() throws TestException {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123");

			statement = connection.createStatement();

			statement.execute(QueryMapper.createQuery);
			System.out.println("table created");

		} catch (ClassNotFoundException e) {
			throw new TestException("class not loaded");
		} catch (SQLException e) {
			throw new TestException("connection not established");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new TestException("unable to close the statement");
			}

			try {
				connection.close();
			} catch (SQLException e) {
				throw new TestException("unable to close the connection");
			}
		}

	}

}
