package com.cg.jdbc.demo;

import com.cg.exceptions.TestException;

public class Main {

	public static void main(String[] args) {

		JdbcOperations operations = new JdbcOperations();
		try {
			operations.createStudentTable();
		} catch (TestException e) {
			System.err.println(e.getMessage());
		}

	}

}
