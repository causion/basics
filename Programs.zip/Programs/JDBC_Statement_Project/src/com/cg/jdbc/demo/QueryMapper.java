package com.cg.jdbc.demo;

public interface QueryMapper {

	public static final String createQuery = 
			"create table student_master(id number primary key,name varchar2(20),address varchar2(20))";

}
