package com.cg.pms.Service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.beans.Mobiles;
import com.cg.pms.beans.PurchaseDetails;
import com.cg.pms.dao.CustomerDaoImpl;
import com.cg.pms.dao.ICustomerDao;

public class CustomerServiceImpl implements ICustomerService {
	ICustomerDao dao;
	public CustomerServiceImpl(){
		dao= new CustomerDaoImpl();
	}
	public int addPurchase(PurchaseDetails purchasedetails) throws PurchaseException
	{
		return dao.addPurchase(purchasedetails);
	}
	public boolean validatePurchaseDetails(PurchaseDetails purchasedetails) throws PurchaseException{
		Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]{4,20}");
		Matcher matcher=pattern.matcher(purchasedetails.getCname());
		if(matcher.matches()==false)
			throw new PurchaseException("Name is not valid");
		/*Pattern pattern1=Pattern.compile("/^w+[+.w-]*@([w-]+.)*w+[w-]*.([a-z]{2,4}|d+)$/i");
		Matcher matcher1=pattern1.matcher(purchasedetails.getMailid());
		if(matcher1.matches()==false)
			throw new PurchaseException("Email is not valid");*/
		
		Pattern pattern2=Pattern.compile("(7|8|9){1}[0-9]{9}");
		Matcher matcher2=pattern2.matcher(purchasedetails.getPhoneno());
		if(matcher2.matches()==false)
			throw new PurchaseException("Phone Number is not valid");
		
		List<Mobiles> mlist=dao.getMobiledetails();
		if(mlist.stream().filter(c->c.getMobileid()==purchasedetails.getMobileid()).count()==0){
			throw new PurchaseException("Invalid mobile id");
		}
		return true;
	}
	
	@Override
	public ArrayList<Mobiles> getMobiledetails() throws PurchaseException {
		// TODO Auto-generated method stub
		return dao.getMobiledetails();
	}
	@Override
	public int deleteMobileDetails(int mobileid) throws SQLException, PurchaseException {
		// TODO Auto-generated method stub
		return dao.deleteDetails(mobileid);
	}
	@Override
	public List<String> getMobiles(double price) {
		return dao.getMobiles(price);
	}
	@Override
	public PurchaseDetails getPurchaseDetails(int purchaseid) throws SQLException {
		PurchaseDetails puechaseDetails=dao.getPurchaseDetails(purchaseid);
		return puechaseDetails;
	}

}
