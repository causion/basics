package com.cg.javaintro.bean;

public interface IMyInterface {

	public float calculateArea();
	
}
