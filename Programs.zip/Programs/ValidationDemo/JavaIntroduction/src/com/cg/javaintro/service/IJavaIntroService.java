package com.cg.javaintro.service;

public interface IJavaIntroService {

	
	public boolean validateEmpId(String id);
	public boolean validateEmpName(String name);
}
