package com.cg.rs;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {

	private String eid;
	private String name;
	private String post;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String eid, String name, String post) {
		super();
		this.eid = eid;
		this.name = name;
		this.post = post;
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	@Override
	public String toString() {
		return "\n eid=" + eid + ", name=" + name + ", post=" + post;
	}
	
	
}
