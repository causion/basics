package com.cg.rs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeDao {

	public static final Map<String, Employee> map=new HashMap<String, Employee>();
	
	public static void init() {
		Employee e1=new Employee("E01","priya","Trainer");
		Employee e2=new Employee("E04","Riya","SoftwareDeveloper");
		Employee e3=new Employee("E03","Sriya","SE");
		Employee e4=new Employee("E02","Diya","Admin");
		Employee e5=new Employee("E05","Anu","ASE");
		map.put(e1.getEid(), e1);
		map.put(e2.getEid(), e2);
		map.put(e3.getEid(), e3);
		map.put(e4.getEid(), e4);
		map.put(e5.getEid(), e5);
	}
	static {
		init();
	}
	
	public Employee getbyid(String eid) {
		System.out.println("eid-"+eid);
		Employee e=map.get(eid);
		System.out.println(e);
		return e;
	}
	
	public Employee addEmployee(Employee e) {
		map.put(e.getEid(), e);
		return e;
	}
	public Employee updateEmployee(Employee e) {
		map.put(e.getEid(), e);
		return e;
	}
	public void deleteEmployee(String eid) {
		map.remove(eid);
		System.out.println(eid+" removed");
		}
	
	public List<Employee> getAllemployee(){
		ArrayList<Employee> emplist=new ArrayList<Employee>();
	Collection<Employee> emps=map.values();
	emplist.addAll(emps);
	return emplist;
	}
	
	
	
	
}
