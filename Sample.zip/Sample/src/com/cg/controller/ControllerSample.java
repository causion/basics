package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerSample {

	@RequestMapping("/")
	public String welcome() {
		return "welcome";
	}
}
