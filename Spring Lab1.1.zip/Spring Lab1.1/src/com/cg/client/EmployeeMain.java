package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp=context.getBean(Employee.class);
		System.out.println("Employee Details");
		System.out.println("----------------------------");
		System.out.println(emp);
		
		

	}

}
