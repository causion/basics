package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;
import com.cg.SBU;

public class MainClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		SBU sb=context.getBean(SBU.class);
		System.out.println("Employee Details");
		System.out.println("----------------------------");
		System.out.println(sb);

	}

}
