package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class LifeCycle implements InitializingBean,DisposableBean,BeanNameAware,BeanPostProcessor{

	
	
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("init from intialization");
		
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("destroy from disposalbean");
		
	}

	@Override
	public void setBeanName(String name) {
		
		System.out.println("BeanAware=>"+name);
	}

	@Override
	public Object postProcessAfterInitialization(Object arg0, String arg1) throws BeansException {
		// TODO Auto-generated method stub
	System.out.println("After-bean post process");
		return null;
	}

	@Override
	public Object postProcessBeforeInitialization(Object arg0, String arg1) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("Before-bean post process");
		return null;
	}
	
	
	 
}
