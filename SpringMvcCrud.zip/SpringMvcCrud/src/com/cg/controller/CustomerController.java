package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Customer;
import com.cg.model.Gender;
import com.cg.service.CustomerService;

@Controller
public class CustomerController {
	@Autowired
	Customer customer;
	@Autowired
	CustomerService customerService;
	@RequestMapping("/")
	public String loginPage() {
		return "login";
	}
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public ModelAndView loginValidation(@RequestParam String username,@RequestParam String password,HttpServletRequest request) {
		ModelAndView modelAndView=new ModelAndView();
		Customer customer=customerService.validate(username, password);
		HttpSession session=request.getSession();
		if(customer!=null&&customer.getRole().equals("customer")) {
			session.setAttribute("customer", customer);
			modelAndView.setViewName("customerhome");
		}else if(customer!=null&&customer.getRole().equals("admin")) {
			session.setAttribute("customer", customer);
			modelAndView.setViewName("adminhome");
		}else {
			modelAndView.addObject("status", "Invalid username/password");
			modelAndView.setViewName("login");
		}
		return modelAndView;
		
	}
	
	@RequestMapping("/registerlink")
	public String registerlink(Model model) {
		model.addAttribute(customer);
		return "register";	
	}
	
	@ModelAttribute("genderlist")
	public List<Gender> populate(){
		List<Gender> genderlist=new ArrayList<>();
		Gender g1=new Gender();
		g1.setType("Male");
		Gender g2=new Gender();
		g2.setType("Female");
		genderlist.add(g1);
		genderlist.add(g2);
		return genderlist;
		
	}
	
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView register(@Valid Customer customer,BindingResult result) {
		ModelAndView modelView=new ModelAndView();	
		if(result.hasErrors()) {
			modelView.setViewName("register");
			
		}
		else {
			customerService.save(customer);
			modelView.setViewName("login");
			modelView.addObject("status","Register successfully...");
		}
		return modelView;
	}
	
	@RequestMapping ("/viewprofile")
	public String viewProfile() {
		return "customerhome";
	}
	
	@RequestMapping ("/updateprofile")
	public String updateProfile(Model map,HttpServletRequest request) {
		HttpSession session=request.getSession();
		Customer customer=(Customer)session.getAttribute("customer");
		map.addAttribute(customer);
		return "update";
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView update(@Valid Customer customer,BindingResult result) {
		ModelAndView modelView=new ModelAndView();	
		if(result.hasErrors()) {
			modelView.setViewName("update");
			
		}
		else {
			customerService.update(customer);
			modelView.setViewName("login");
			modelView.addObject("status","updated successfully...");
		}
		return modelView;
	}
	@RequestMapping ("/viewall")
	public ModelAndView viewAll() {
		ModelAndView modelView=new ModelAndView();
		List<Customer> custlist=customerService.getAllCustomers();
		modelView.addObject("customerlist", custlist);
		modelView.setViewName("adminhome");
		return modelView;
	}
	
	@RequestMapping ("/searchbyid")
	public String searchById() {
		return "search";
	}
	
	@RequestMapping ("/delete")
	public String deleteById(@RequestParam Integer custId) {
		customerService.delete(custId);
		return "adminhome";
	}
	
	@RequestMapping ("/search")
	public ModelAndView search(@RequestParam Integer custId) {
		Customer customer=customerService.getById(custId);
		ModelAndView modelView=new ModelAndView();
		modelView.addObject("customer1", customer);
		modelView.setViewName("search");
		if(customer==null) {
			modelView.addObject("status", "Customer Id is Invalid");		
		}
		return modelView;
	}

}
