package com.cg.dao;

import java.util.List;

import com.cg.model.Customer;

public interface CustomerRepository {
	
	public void save(Customer customer);
	public void update(Customer customer);
	public boolean delete(int custId);
	public Customer getById(int custId);
	public List<Customer> getAllCustomers();
	public Customer validate(String username,String password);
}
