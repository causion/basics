package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	@Override
	public void save(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.persist(customer);

	}
 
	@Transactional
	@Override
	public void update(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.merge(customer);

	}

	@Transactional
	@Override
	public boolean delete(int custId) {
		// TODO Auto-generated method stub
		Customer customer=entityManager.find(Customer.class, custId);
		entityManager.remove(customer);
		return true;
	}

	@Override
	public Customer getById(int custId) {
		// TODO Auto-generated method stub
		Customer customer = null;
		try {
			customer = entityManager.find(Customer.class, custId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query=entityManager.createQuery("from Customer",Customer.class);
		List<Customer> custlist=query.getResultList();
			
		return custlist;
	}

	@Override
	public Customer validate(String username, String password) {
		// TODO Auto-generated method stub
		Customer customer = null;
		try {
			TypedQuery<Customer> query=entityManager.createQuery(
					"select c from Customer c where c.username=?1 and c.password=?2"
					,Customer.class);
			query.setParameter(1, username);
			query.setParameter(2, password);
			query.setMaxResults(1);
			customer = query.getSingleResult();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

}
