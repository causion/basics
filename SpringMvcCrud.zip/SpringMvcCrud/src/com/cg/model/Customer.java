package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Customer {
	
	@Id
	@GeneratedValue(generator="custseq",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="custseq",sequenceName="custseq1",initialValue=1000,allocationSize=1)
	@Column(length=5)
	private int custId;
	@NotBlank(message="user name should not be empty")
	@Pattern(regexp="^[A-Za-z]{5,20}$",message="username should be match with pattern")
	@Column(length=20)
	private String username;
	@NotBlank(message="password must be entered")
	@Size(min=5,max=15,message="password length min 5")
	@Column(length=15)
	private String password;
	@NotNull(message="enter phone number")
	@Column(length=10)
	private long phone;
	@NotBlank(message="must enter email")
	@Email(message="Invalid email id")
	@Column(length=25)
	private String email;
	@NotNull(message="provide age value")
	@Min(value=18,message="age must be >=18")
	@Column(length=3)
	private int age;
	@Column(length=10)
	private String gender;
	@Column(length=10)
	private String role;
	public Customer() {
		
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", username=" + username + ", password=" + password + ", phone=" + phone
				+ ", email=" + email + ", age=" + age + ", gender=" + gender + ", role=" + role + "]";
	}

}
