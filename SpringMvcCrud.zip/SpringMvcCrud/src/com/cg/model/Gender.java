package com.cg.model;

public class Gender {
	
	private String type;

	public Gender() {
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
