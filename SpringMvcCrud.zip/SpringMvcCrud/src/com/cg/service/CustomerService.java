package com.cg.service;

import java.util.List;

import com.cg.model.Customer;

public interface CustomerService {

	public boolean save(Customer customer);
	public boolean update(Customer customer);
	public boolean delete(int custId);
	public Customer getById(int custId);
	public List<Customer> getAllCustomers();
	public Customer validate(String username,String password);

}
