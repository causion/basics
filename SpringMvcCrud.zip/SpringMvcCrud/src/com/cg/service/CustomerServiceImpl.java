package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CustomerRepository;
import com.cg.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public boolean save(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.save(customer);
		return true;
	}

	@Override
	public boolean update(Customer customer) {
		
		// TODO Auto-generated method stub
		customerRepository.update(customer);
		return true;
	}

	@Override
	public boolean delete(int custId) {
		// TODO Auto-generated method stub
		customerRepository.delete(custId);
		return true;
	}

	@Override
	public Customer getById(int custId) {
		// TODO Auto-generated method stub
		return customerRepository.getById(custId);

	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.getAllCustomers();
	}

	@Override
	public Customer validate(String username, String password) {
		// TODO Auto-generated method stub
		return customerRepository.validate(username, password);
	}

}
