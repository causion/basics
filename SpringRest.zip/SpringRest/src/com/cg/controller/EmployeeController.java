package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Employee;
import com.cg.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="/hi",method=RequestMethod.GET)
	public String hi() {
		return "Welcome";
	}
	
	
	@RequestMapping(value="/allemp",method=RequestMethod.GET)
	public List<Employee> getALLEmployees(){
		return employeeService.getEmployees();		
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Employee add(@RequestBody Employee employee) {
		return employeeService.addEmployee(employee);
		
	}
	
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Employee update(@RequestBody Employee employee) {
		return employeeService.updateEmployee(employee);
		
	}
	
	@RequestMapping(value="/delete/{eid}",method=RequestMethod.PUT)
	public Employee deleteById(@PathVariable int eid) {
		return employeeService.deleteById(eid);
		
	}
	
	@RequestMapping(value="/get/{eid}",method=RequestMethod.GET)
	public Employee getBybyid(@PathVariable int eid) {
		return employeeService.getEmployee(eid);
		
	}
	
	
	@RequestMapping(value="/getbyid",method=RequestMethod.GET)
	public Employee getBybyId(@PathVariable int eid) {
		return employeeService.getEmployee(eid);
		
	}


}
