package com.cg.dao;

import java.util.List;

import com.cg.model.Employee;

public interface EmployeeDao {
	
	List<Employee> getEmployees();
	Employee getEmployee(int eid);
	void addEmployee(Employee e);
	Employee updateEmployee(Employee e);
	void deleteById(int eid);

}
