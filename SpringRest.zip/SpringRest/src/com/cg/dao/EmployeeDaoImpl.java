package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		TypedQuery<Employee> query=entityManager.createQuery("select e from Employee e",Employee.class);
		List<Employee> emplist=query.getResultList();
		return emplist;
	}

	@Override
	public Employee getEmployee(int eid) {
		// TODO Auto-generated method stub
		Employee employee=entityManager.find(Employee.class, eid);
		return employee;
	}

	@Transactional
	@Override
	public void addEmployee(Employee e) {
		// TODO Auto-generated method stub
		entityManager.persist(e);

	}

	@Transactional
	@Override
	public Employee updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		Employee employee=entityManager.merge(e);
		return employee;
	}

	@Transactional
	@Override
	public void deleteById(int eid) {
		// TODO Auto-generated method stub
		Employee employee=entityManager.find(Employee.class,eid);
		entityManager.remove(employee);
	}

}
