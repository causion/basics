package com.cg.service;

import java.util.List;

import com.cg.model.Employee;

public interface EmployeeService {
	
	List<Employee> getEmployees();
	Employee getEmployee(int eid);
	Employee addEmployee(Employee e);
	Employee updateEmployee(Employee e);
	Employee deleteById(int eid);

}
