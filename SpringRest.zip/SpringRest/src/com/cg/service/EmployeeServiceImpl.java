package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeDao;
import com.cg.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getEmployees();
	}

	@Override
	public Employee getEmployee(int eid) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployee(eid);
	}

	@Override
	public Employee addEmployee(Employee e) {
		// TODO Auto-generated method stub
		employeeDao.addEmployee(e);
		return e;
	}

	@Override
	public Employee updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		Employee employee=employeeDao.updateEmployee(e);
		return employee;
	}

	@Override
	public Employee deleteById(int eid) {
		// TODO Auto-generated method stub
		Employee employee=employeeDao.getEmployee(eid);
		employeeDao.deleteById(eid);
		return employee;
	}

}
