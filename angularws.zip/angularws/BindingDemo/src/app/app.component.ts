import { Component } from '@angular/core';
import { ParseTreeResult } from '../../node_modules/@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BindingDemo Example';

  fname:string="siva";
  lname:string="L";
  myname:string;
  isVisible:boolean=false;
  count:number=0;
  name:string="";
  applyBold:boolean=true;
  applyItalic:boolean=true;

  addClasses(){
    let classes={
      boldClass:this.applyBold,
      italicClass:this.applyItalic
    }
    return classes;
  }

  addStyles(){
    let styles={
      'color':'red',
      'font-size.px':20
    }
    return styles;
  }
  btnClick():number{
    return ++this.count;
  }

  getFullName():string{
    this.myname=this.fname+this.lname;
    return this.myname;
  }
}
