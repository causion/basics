import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { FormGroup } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  title:string="ADD Employee Form";
  empData:Employee={"id":0,"name":'',"email":'',"phone":0}
  addForm:FormGroup;

  constructor() { }

  ngOnInit() {
  }
  onSubmit(){
    console.log(this.empData.id+"\t"+this.empData.name+"\t"+this.empData.email+"\t"+this.empData.phone);
  }

}
