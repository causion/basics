import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product';
@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  products:Product[];
  constructor(private service:ProductService) { }

  ngOnInit() {
    this.service.getProducts().subscribe((data:Product[])=>{this.products=data});
    console.log(this.products);
  }

  deleteProduct(p:Product){
    this.service.deleteProduct(p).subscribe(
      (result)=>{this.products=this.products.filter(pp=>pp!==p)}
    );
  }

}
