import { Injectable } from '@angular/core';

import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  searchedData:Product[];
  url:string="http://localhost:3000/product";

  constructor(private http:HttpClient) { }

  getProducts(){
    return this.http.get<Product[]>(this.url);
  }

  addProduct(product:Product){
    return this.http.post(this.url,product);
  }
  deleteProduct(product:Product){
    return this.http.delete<Product[]>(this.url+"/"+product.id); 
  }
  setsearchdata(searchedData:Product[]){
this.searchedData=searchedData;
console.log("service:"+searchedData)
  }
  getSearchedData(){
    return this.searchedData;
  }
}


