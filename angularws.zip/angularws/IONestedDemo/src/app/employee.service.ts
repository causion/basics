import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 
  constructor() {}
  getEmployees():Employee[]{
  return [
    {empId:'101',name:'siva',gender:'male',salary:1800000,dob:'1/1/1996'},
    {empId:'102',name:'kanna',gender:'male',salary:60000,dob:'6/6/1996'},
    {empId:'103',name:'jaswanth',gender:'male',salary:66000,dob:'6/6/1996'},
    {empId:'104',name:'aishu',gender:'female',salary:88000,dob:'6/10/1995'},
    {empId:'105',name:'mouni',gender:'female',salary:87000,dob:'29/4/1996'}
    
];

}

}
