export class Employee {
    empId:string;
    name:string;
    gender:string;
    salary:number;
    dob:string;
}
