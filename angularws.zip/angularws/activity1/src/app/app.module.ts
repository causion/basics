import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Routes, RouterModule} from '@angular/router';
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { ProductService } from './service/product.service';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { ShowsearcheddataComponent } from './showsearcheddata/showsearcheddata.component';

const routes:Routes=[
  {path:'',redirectTo:'listproduct',pathMatch:'full'},
  {path:'listproduct',component:ProductlistComponent},
  {path:'add',component:AddproductComponent},
  {path:'search',component:SearchproductComponent},
  {path:'searcheddata',component:ShowsearcheddataComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    AddproductComponent,
    ProductlistComponent,
    SearchproductComponent,
    ShowsearcheddataComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,RouterModule.forRoot(routes),HttpClientModule 
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
