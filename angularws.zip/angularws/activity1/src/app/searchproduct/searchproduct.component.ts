import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product';

@Component({
  selector: 'app-searchproduct',
  templateUrl: './searchproduct.component.html',
  styleUrls: ['./searchproduct.component.css']
})
export class SearchproductComponent implements OnInit {

  sname:string;
products:Product[];
searchedData:Product[];
 status:string="";
  constructor(private service:ProductService) { }

  ngOnInit() {
    this.service.getProducts().subscribe((data:Product[])=>{this.products=data});
     }

     searchByName(){

       for(let p of this.products){
        this.searchedData= this.products.filter(p=>p.name.toLowerCase().indexOf(this.sname.toLowerCase())!==-1);
      this.status="Found the data, check in showsearcheddata page"
      }
      if(this.searchedData.length==0){
        this.status="Data Not Found";

      }      
       this.service.setsearchdata(this.searchedData);
     }
}
