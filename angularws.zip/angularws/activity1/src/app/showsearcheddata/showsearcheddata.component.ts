import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-showsearcheddata',
  templateUrl: './showsearcheddata.component.html',
  styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {
  searcheddata:Product[];
  constructor(private service:ProductService) { }

  ngOnInit() {
    this.searcheddata=this.service.getSearchedData();
  }

}
