import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {Routes,RouterModule} from  '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './updatecustomer/updatecustomer.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { CustomerService } from './service/customer.service';
import { MycustComponent } from './mycust/mycust.component';

const routes:Routes=[
  {path:'',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'listcustomer',component:CustomerlistComponent},
  {path:'add',component:AddcustomerComponent},
  {path:'update/:id',component:UpdatecustomerComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:MycustComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CustomerlistComponent,
    AddcustomerComponent,
    UpdatecustomerComponent,
    AboutComponent,
    ContactComponent,
    MycustComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,RouterModule.forRoot(routes),HttpClientModule
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
