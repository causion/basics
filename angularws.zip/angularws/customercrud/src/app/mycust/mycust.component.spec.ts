import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MycustComponent } from './mycust.component';

describe('MycustComponent', () => {
  let component: MycustComponent;
  let fixture: ComponentFixture<MycustComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MycustComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MycustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
