import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { FormBuilder, FormGroup, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {
  custData:Customer={"id":0,"name":'',"email":'',"phone":0}
  custForm:FormGroup;
  submitted:boolean=false;

  constructor(private service:CustomerService,private router:Router,private aroute:ActivatedRoute,private formbuilder:FormBuilder) {}

  ngOnInit() {
    this.aroute.params.subscribe(
      (params)=>{
        this.service.getById(params['id']).subscribe(
          (result)=>{this.custData=result}

        );
      });
      console.log(this.custData)
      /*this.custForm=this.formbuilder.group({
        id:['',Validators.required,'',Validators.pattern('[0-9]{2,5}')],
        name:['',Validators.required,'',Validators.pattern('[a-zA-Z]{5,30}')],
        email:['',Validators.required,'',Validators.email],
        phone:['',Validators.required,'',Validators.pattern('[0-9]{10}')]

  });*/
  }

  onSubmit(){
   // this.submitted=true;
    //this.custData=this.custForm.value;
    this.service.updateCustomer(this.custData).subscribe(
      (data)=>{this.router.navigate(['listcustomer'])});

   // if(this.custForm.invalid) return;    
  }
}
