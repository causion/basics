import { Accountmaster } from './accountmaster';

describe('Accountmaster', () => {
  it('should create an instance', () => {
    expect(new Accountmaster()).toBeTruthy();
  });
});
