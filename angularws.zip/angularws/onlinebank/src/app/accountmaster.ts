export class Accountmaster {
    accountNumber:number;
    accountType:string;
    accountBalance:number;
    openDate:Date;
    interestRate:number;
    accountHolderName:string;
    email:string;
    address:string;
    panNumber:string
}

