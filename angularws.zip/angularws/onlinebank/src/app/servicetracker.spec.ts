import { Servicetracker } from './servicetracker';

describe('Servicetracker', () => {
  it('should create an instance', () => {
    expect(new Servicetracker()).toBeTruthy();
  });
});
