export class Servicetracker {
    serviceId:number;
    serviceDescription:string;
    accountNumber:string;
    serviceRaisedDate:Date;
    serviceStatus:string

}
