import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {Routes,RouterModule} from  '@angular/router';
import { AppComponent } from './app.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { UpdatecustomerComponent } from './updatecustomer/updatecustomer.component';
import { MycustComponent } from './mycust/mycust.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { CustomerService } from './service/customer.service';


const routes:Routes=[
  {path:'',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'listcustomer',component:CustomerlistComponent},
  {path:'add',component:AddcustomerComponent},
  {path:'update/:id',component:UpdatecustomerComponent},
  
];

@NgModule({
  declarations: [
    AppComponent,
    CustomerlistComponent,
    UpdatecustomerComponent,
    MycustComponent,
    AddcustomerComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,RouterModule.forRoot(routes),HttpClientModule
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
