import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
  customers:Customer[];

  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.service.getCustomers().subscribe((data:Customer[])=>{this.customers=data});
    console.log(this.customers);
  }
  deleteCustomer(c:Customer){
    this.service.deleteCustomer(c).subscribe(
      (result)=>{this.customers=this.customers.filter(cc=>cc!==c)}
    );
  }

}
