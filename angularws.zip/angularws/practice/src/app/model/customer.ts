export class Customer {
    id:number;
    name:string;
    price:number;
    brand:string;
}
