import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-mycust',
  templateUrl: './mycust.component.html',
  styleUrls: ['./mycust.component.css']
})
export class MycustComponent implements OnInit {
  custData:Customer={"id":0,"name":'',"price":0,"brand":''}
  custForm:FormGroup;
  submitted:boolean=false;

  constructor(private formbuilder:FormBuilder, private service:CustomerService,private router:Router) { }


  ngOnInit() {
    this.custForm=this.formbuilder.group({
        id:['',Validators.required,'',Validators.pattern('[0-9]{2,5}')],
        name:['',Validators.required,'',Validators.pattern('[a-zA-Z]{5,30}')],
        price:['',Validators.required,'',Validators.pattern('[0-9]{2,5}')],
        brand:['',Validators.required,'',Validators.pattern('[a-zA-Z]{5,30}')]

  });
  }
  onSubmit(){
    this.submitted=true;
     this.custData=this.custForm.value;
    if(this.custForm.invalid) return; 
    else{
    
    alert(this.custData.id+""+this.custData.name);
    this.service.addCustomer(this.custData).subscribe(
      (data)=>{
        this.router.navigate(['listcustomer']);
      }
    );
      
  }
}
}
