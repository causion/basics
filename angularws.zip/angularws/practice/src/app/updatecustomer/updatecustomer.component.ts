import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { FormBuilder, FormGroup, Validators } from '../../../node_modules/@angular/forms';



@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {
  custData:Customer={"id":0,"name":'',"price":0,"brand":''}
  custForm:FormGroup;
  submitted:boolean=false;

  constructor(private service:CustomerService,private router:Router,private aroute:ActivatedRoute,private formbuilder:FormBuilder) { }

  ngOnInit() {
    this.aroute.params.subscribe(
      (params)=>{
        this.service.getById(params['id']).subscribe(
          (result)=>{this.custData=result}

        );
      });
      console.log(this.custData)
  }
  onSubmit(){
  
     this.service.updateCustomer(this.custData).subscribe(
       (data)=>{this.router.navigate(['listcustomer'])});
 

   }

}
