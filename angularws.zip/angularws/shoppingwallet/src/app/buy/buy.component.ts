import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { CustService } from '../service/cust.service';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {
  products:Product[];
  name:string;
  amount:number;
  constructor(private service:CustService) { }

  ngOnInit() {
    this.service.getproducts().subscribe((data:Product[])=>{this.products=data});
    console.log(this.products);
    this.name=this.service.getName();
    this.amount=this.service.getAmount();
  }


}
