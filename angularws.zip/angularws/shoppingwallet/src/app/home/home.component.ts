import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';

import { Router } from '@angular/router';
import { CustService } from '../service/cust.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
  custData:Customer={"name":'',"phone":0,"amount":0}
amount:any="";
name:string="";
  constructor(private service:CustService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(){
    console.log(this.custData.name);
    this.amount=this.custData.amount;
    this.name=this.custData.name;
    this.service.addCustomer(this.custData).subscribe((data)=>{
        this.router.navigate(['buy']);
      });
      this.service.setAmount(this.amount);
      this.service.setName(this.name);
  }




}
