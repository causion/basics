export class Product {
    id:number;
    pname:string;
    price:number;
    
}
