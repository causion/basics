import { Component } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './service/employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'springangular';
  employees:Employee[];
  employees1:Employee[];
  employee:Employee;
  id:any;
  did:any;

  constructor(private service:EmployeeService){}
  ngOnInit(){
    this.service.getAll().subscribe((data:Employee[])=>{
       this.employees=data;
    });
    console.log(this.employees);
  }
  getById(){
    this.service.getById(this.id).subscribe((data:Employee)=>{
      this.employee=data;});
  }

  deleteById(){
    this.service.delete(this.did).subscribe((data:Employee[])=>{
      this.employees1=data;});
  }

}
