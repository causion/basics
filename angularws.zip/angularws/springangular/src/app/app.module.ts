import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {Routes,RouterModule} from  '@angular/router';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { AppComponent } from './app.component';
import { EmployeeService } from './service/employee.service';


const routes:Routes=[
  {path:'',redirectTo:'',pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,RouterModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
