export class Employee {
    empId:number;
    name:string;
    salary:number
}
