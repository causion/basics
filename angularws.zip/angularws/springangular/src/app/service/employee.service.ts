import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Employee } from '../employee';
import { THIS_EXPR } from '../../../node_modules/@angular/compiler/src/output/output_ast';
import { templateJitUrl } from '../../../node_modules/@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url:string="http://localhost:8082/Springangularrest";

  constructor(private http:HttpClient) { }
  getAll(){
    return this.http.get<Employee[]>(this.url+"/allemp");
  }
  getById(id){
    return this.http.get<Employee>(this.url+"/"+id);
  }


  add(employee:Employee){
    return this.http.get<Employee>(this.url+"/add");
  }
   

  update(employee:Employee){
    return this.http.put(this.url+"/update",employee);
  }
  delete(id){
    return this.http.delete<Employee[]>(this.url+"/delete/"+id);
  }
}
