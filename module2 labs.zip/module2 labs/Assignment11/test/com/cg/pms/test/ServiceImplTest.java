package com.cg.pms.test;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.Service.CustomerServiceImpl;
import com.cg.pms.beans.PurchaseDetails;

public class ServiceImplTest {

	@Test
	public void test() throws PurchaseException {
		CustomerServiceImpl impl = new CustomerServiceImpl();
		PurchaseDetails details = new PurchaseDetails();
		details.setCname("asdd");
		details.setPhoneno("456");
		details.setMobileid(1000);
		boolean actual = impl.validatePurchaseDetails(details);
		boolean expected = false;
		Assert.assertEquals(expected, actual);
	}
	
	

}
