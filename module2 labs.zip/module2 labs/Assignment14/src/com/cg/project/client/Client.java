package com.cg.project.client;

import com.cg.project.services.EmployeeService;

public class Client {
	public static void main(String[] args) {
		EmployeeService service=new EmployeeService();
		
		System.out.println("Total Salary : "+service.totalSal());
		System.out.println("_______________________________________________________________");
		System.out.println("Department info :");
		service.departmentInfo();
		System.out.println("_______________________________________________________________");
		System.out.println("Employees w/o department using Stream : ");
		service.empWithoutDep();
		System.out.println("_______________________________________________________________");
		System.out.println("Department w/o employees using Stream: ");
		service.depWithoutEmp();
		System.out.println("_______________________________________________________________");
		System.out.println("Department with highest no. of employees");
		service.highestEmpDep();
		System.out.println("_______________________________________________________________");
	}
}