package com.cg.project.services;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.cg.project.beans.Employee;
import com.cg.project.util.EmployeeRepository;

@SuppressWarnings("unused")
public class EmployeeService {
	EmployeeRepository repository = new EmployeeRepository();
	List<Employee>empList=new ArrayList<>(EmployeeRepository.employees.values());
	
	public double totalSal() {
		return empList.stream().mapToDouble(emp->emp.getSalary()).sum();	
	}
	public void departmentInfo() {
		List<String> deps = empList.stream().map(emp->emp.getDepartment().getDepartmentName()).distinct().collect(Collectors.toList());
		for (String string : deps)
			System.out.println("Department "+string+" : "+empList.stream().filter(emp->string.equals(emp.getDepartment().getDepartmentName())).count());
	}
	public void empWithoutDep() {
		String s="";
		List<Employee> counts= new ArrayList<>();
			 counts = empList.stream().filter(emp->s.equals(emp.getDepartment().getDepartmentName())).collect(Collectors.toList());
			 for (Employee employee : counts) {
				System.out.println(employee);
			}
	}
	public void depWithoutEmp() {
		List<Employee> counts= new ArrayList<>();
			 counts = empList.stream().filter(emp->0==emp.getEmployeeId()).collect(Collectors.toList());
			 for (Employee employee : counts) {
				System.out.println(employee);
			 }
	}
	public void highestEmpDep() {
	     List<Long>count=new ArrayList<>();
		List<String> deps = empList.stream().map(emp->emp.getDepartment().getDepartmentName()).distinct().collect(Collectors.toList());
		for (String string : deps)
			count.add(empList.stream().filter(emp->string.equals(emp.getDepartment().getDepartmentName())).count());
	  long max=Collections.max(count);
	  
	  for (String string : deps)
			if(empList.stream().filter(emp->string.equals(emp.getDepartment().getDepartmentName())).count()==max)
				System.out.println("Department="+string+" Employees="+max);
	}
}