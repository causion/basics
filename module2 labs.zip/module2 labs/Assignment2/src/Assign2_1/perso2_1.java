package Assign2_1;

class perso2_1{
	public static void main(String args[]){
		System.out.println("Person Details:");
		System.out.println("________________\n");
		System.out.println("First Name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");
	
	
	}
}