package Assign2_3and2_4;
import java.util.Scanner;
public class People_details {

	public static void main(String[] args) {
		String fname,lname;
		char gender;
		Scanner scn= new Scanner(System.in);
		System.out.println("Enter first name");
		fname = scn.nextLine();
		System.out.println("Enter last name");
		lname = scn.nextLine();
		System.out.println("Enter gender");
		gender = scn.next().charAt(0);
		scn.close();
		System.out.println("Personal details \n______________\n");
		PersonDetails myObj = new PersonDetails(fname,lname,gender);
		myObj.setfName(fname);
		myObj.setlName(lname);
		myObj.setGender(gender);

	}

}

