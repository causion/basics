package Assign2_3and2_4;
import java.util.Scanner;
public class People_details_phonenumber {
	public static void main(String[] args) {
		
		char gender;
		long pnum;
		Scanner scn= new Scanner(System.in);
		System.out.println("Enter first name");
		String fname = (String) scn.nextLine();
		System.out.println("Enter last name");
		String lname = (String) scn.nextLine();
		System.out.println("Enter gender");
		gender = scn.next().charAt(0);
		System.out.print("Enter phone number:");
		pnum = scn.nextLong();
		scn.close();
		PersonDetails myObj = new PersonDetails(fname,lname,gender);
		PersonDetails myObj_phone = new PersonDetails(pnum);
		myObj.setfName(fname);
		myObj.setlName(lname);
		myObj.setGender(gender);
		myObj_phone.setPnum(pnum);

	}

}
