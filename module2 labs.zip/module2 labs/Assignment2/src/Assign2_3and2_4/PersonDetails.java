package Assign2_3and2_4;
public class PersonDetails {

	private String fname;
	private String lname;
	private char gender;
	private long pnum; 
	
	PersonDetails(){

	}

	PersonDetails(String fname,String lname, char gender){
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		printAll();
	}
	PersonDetails(long pnum){
		this.pnum = pnum;
		printnum();
		
	}
	public String getfName() {
		return fname;
	}

	public void setfName(String fname) {
		this.fname = fname;
	}

	public String getlName() {
		return lname;
	}

	public void setlName(String lname) {
		this.lname = lname;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	public long getPnum(long pnum){
		return pnum;
	}
	public void setPnum(long pnum){
		this.pnum = pnum;
	}
	

	public final void printAll() {
		System.out.println("First name:"+fname+"\nLast name:"+lname+"\nGender:"+gender);
	}
	public final void printnum() {
		System.out.println("Phone number"+pnum);
	}

	
	
	
}

