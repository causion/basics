package Assign2_5;

public enum Gender 
{
    M,F;
}
