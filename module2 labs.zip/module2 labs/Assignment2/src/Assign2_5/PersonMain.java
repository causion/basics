package Assign2_5;

public class PersonMain 
{
	String firstName;
	String lastName;
	//char gender;
	Gender gender;
	
	public PersonMain()
	{
		firstName=null;
		lastName=null;
		//gender='\u0000';
		gender=Gender.M;
	}
	public PersonMain(String firstName,String lastName,Gender gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
	}
	public void personDetailsDisp()
	{
		System.out.println("First Name:"+this.firstName);
		System.out.println("Last Name:"+this.lastName);
		System.out.println("Gender:"+this.gender);
	}
	public void personPhoneNumber(long number)
	{
		System.out.println("Phone Number="+number);
	}
}

