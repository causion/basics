package Assign2_5;
import java.util.*;
public class TestPersonMain {

	public static void main(String[] args) {
		Gender gend;
		Scanner scn = new Scanner(System.in);
		System.out.println("enter first name");
		String fname = scn.next();
		System.out.println("enter last name");
		String lname = scn.next();
		System.out.println("enter gender M/F");
		String gen = scn.next();
		if (gen == "F" || gen == "f"){
			gend = Gender.F;
		}
		else{
			gend = Gender.M;
		}
		System.out.println("enter phone number");
		long phone = scn.nextLong();
		PersonMain pm1=new PersonMain(fname,lname,gend);
		pm1.personDetailsDisp();
		pm1.personPhoneNumber(phone);
		
		scn.close();

	}

}
