package Assign3_1;
public class Odd_upper {
	String str, outputStr;
	Odd_upper(String s){
		this.str = s;
		String [] chars = str.split("");
		outputStr = "";
		for (int i = 0; i < chars.length; i++) {
			if (i%2 == 0) {
				outputStr = outputStr + chars[i].toLowerCase();
			}
			else {
				outputStr = outputStr + chars[i].toUpperCase();
			}
		}

		System.out.println(outputStr);
	}
}