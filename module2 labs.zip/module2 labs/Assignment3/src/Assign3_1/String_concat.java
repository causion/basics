package Assign3_1;
public class String_concat {
	String str;
	public String_concat(String s){
		this.str = s;
		System.out.println("Concation of string :"+str+str);
	}
}
