package Assign3_1;

public class String_duplicates {
	String_duplicates(String s){   
		String x = s;

		for(int i=0;i<x.length()-1;i++){
			x = x.substring(0,i+1) + (x.substring(i+1)).replace(String.valueOf(x.charAt(i)), "");
		}
		System.out.println(x);

	} 
}


