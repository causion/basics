package Assign3_1;

import java.util.Scanner;
public class String_operations {
	public static void main(String[] args){
		Scanner scn = new Scanner(System.in);
		System.out.println("enter a string :");
		String s = scn.nextLine();
		System.out.println("Choose any one operation: \n 1.String concat to itself \n 2.replace odd postions with # \n 3.REmove duplicate characters from string \n 4.Change odd characters to upper case");
		int i = scn.nextInt();
		scn.close();
		switch (i) {
		case 1:
			String_concat con = new String_concat(s);
			break;
		case 2:
			String_replace rep = new String_replace(s);
			break;
		case 3:
			String_duplicates dup = new String_duplicates(s);
			break;
		case 4:
			Odd_upper upp = new Odd_upper(s);
			break;
		default:
			System.out.println("wrong choice");
		}
	}
}
