package Assign3_1;
public class String_replace {
	String str;
	String_replace(String s){
		this.str = s;
		for (int i=0; i < str.length(); i++){
			if (i % 2 != 0){
				str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
			}
			
		}
		System.out.println("Changed String"+str);	
	}
}
