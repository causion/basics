package Assign3_2; 
import java.util.Arrays; 
import java.util.Scanner;

public class String_positive { 
	static boolean isAlphabaticOrder(String s){ 
		int n = s.length();  
		char c[] = new char [n];  
		for (int i = 0; i < n; i++) { 
			c[i] = s.charAt(i); 
		} 
		Arrays.sort(c);  
		for (int i = 0; i < n; i++) 
			if (c[i] != s.charAt(i)) 
				return false; 

		return true;	 
	} 

	public static void main(String args[]) 
	{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a String to check whether it is positive or negative");
		String s = sc.next(); 
		sc.close();
		if (isAlphabaticOrder(s)) 
			System.out.println("Given String is Positive"); 
		else
			System.out.println("Given String is Negative"); 

	} 
} 
