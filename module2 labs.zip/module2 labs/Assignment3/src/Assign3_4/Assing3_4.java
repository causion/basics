package Assign3_4;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
public class Assing3_4 {  
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Start date dd");
		int date1 = sc.nextInt();
		System.out.println("enter Start month mm");
		int month1 = sc.nextInt();
		System.out.println("enter start year yyyy");
		int year1 = sc.nextInt();
		System.out.println("enter end date dd");
		int date2 = sc.nextInt();
		System.out.println("enter end month mm");
		int month2 = sc.nextInt();
		System.out.println("enter end year yy");
		int year2 = sc.nextInt();
		sc.close();
		LocalDate pdate = LocalDate.of(year1, month1, date1);
		LocalDate now = LocalDate.of(year2, month2, date2);

		Period diff = Period.between(pdate, now);

		System.out.printf("\nDifference is %d days, %d months and %d years\n\n", 
				diff.getDays()   , diff.getMonths(), diff.getYears());
	}
}

