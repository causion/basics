package Assign3_5;
import java.util.Scanner;
public class Duration {

	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	System.out.println("enter Purchase date dd");
	int day = scn.nextInt();
	System.out.println("enter Purchase date mm");
	int month = scn.nextInt();
	System.out.println("enter Purchase date yy");
	int year = scn.nextInt();
	System.out.println("enter warrenty period years");
	int years = scn.nextInt();
	System.out.println("enter warrenty period months");
	int months = scn.nextInt();
	scn.close();
	int total = (years*12)+months+month; 
	int y = total/12;
	int m = total%12;
	//System.out.println(m+"       "+y);
	int year_change = year+y;
	System.out.println("lastday of warrenty is"+day+"-"+m+"-"+year_change);
	}

}
