package Assign3_6;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Time_zone {

	public static void main(String[] args) {
		ZonedDateTime date = ZonedDateTime.now();
		ZoneId la = ZoneId.of("America/Los_Angeles");
		ZoneId ny = ZoneId.of("America/New_York");
		ZoneId l = ZoneId.of("Europe/London");
		ZoneId t = ZoneId.of("Asia/Tokyo");
		ZoneId p = ZoneId.of("US/Pacific");
		ZoneId c = ZoneId.of("Africa/Cairo");
		ZoneId s = ZoneId.of("Australia/Sydney");
		ZonedDateTime date2 = date.withZoneSameInstant(la);
		ZonedDateTime date3 = date.withZoneSameInstant(ny);
		ZonedDateTime date4 = date.withZoneSameInstant(l);
		ZonedDateTime date5 = date.withZoneSameInstant(t);
		ZonedDateTime date6 = date.withZoneSameInstant(p);
		ZonedDateTime date7 = date.withZoneSameInstant(c);
		ZonedDateTime date8 = date.withZoneSameInstant(s);
		
		System.out.println("Los Angeles"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date2));
		System.out.println("New york"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date3));
		System.out.println("London"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date4));
		System.out.println("Tokyo"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date5));
		System.out.println("Pacific"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date6));
		System.out.println("Cairo"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date7));
		System.out.println("Sydney"+DateTimeFormatter.ofPattern("dd/MM/yyyy - hh:mm").format(date8));
	}

}
