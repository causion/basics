package Assign3_7;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Assign3_7 {
	public static int yy,mm,dd;
	public static String fname,lname;
	public static int calculateAge(int y,int m, int d){
		yy = y;
		mm = m;
		dd = d;
		LocalDate pdate = LocalDate.of(yy, mm, dd);
		LocalDate now = LocalDate.now();

		Period diff = Period.between(pdate, now);

		//System.out.printf("\nAge is years"+diff.getYears());
		int age = diff.getYears();
		return age;
	}
	public static String getFullName(String firstName,String lastName){
		fname = firstName;
		lname = lastName;
	//	System.out.println("name:"+fname+lname);
		return fname+lname;
	}
}
