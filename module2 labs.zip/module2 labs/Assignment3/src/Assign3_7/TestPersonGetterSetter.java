package Assign3_7;

import java.util.Scanner;


public class TestPersonGetterSetter {

	public static void main(String[] args) 
	{
	  PersonGetterSetter p1=new PersonGetterSetter();
	  Assign3_7 assign = new Assign3_7();
	  Scanner scn = new Scanner(System.in);
	  System.out.println("enter first name");
	  String fname = scn.next();
	  System.out.println("enter last name");
	  String lname = scn.next();
	  System.out.println("enter gender");
	  String gender = scn.next();
	  System.out.println("enter date of birth");
	  System.out.println("date:");
	  int date = scn.nextInt();
	  System.out.println("month:");
	  int month = scn.nextInt();
	  System.out.println("year:");
	  int year = scn.nextInt();
	  int age = assign.calculateAge(year, month, date);
	  String name = assign.getFullName(fname, lname);
	  System.out.println("name:"+name+"\n Gender:"+gender+"\n age"+age);
	}

}
