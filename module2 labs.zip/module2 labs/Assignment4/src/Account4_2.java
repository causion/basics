
import java.util.*;
public class Account4_2{  
	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);
		int choice;
		System.out.println("enter amount you want to withdraw");
		double amount =  sc.nextDouble();   
		
		System.out.println("from which type of account do you want to withdraw \n 1.Savings \n 2.Current\n 3.exit");
		choice = sc.nextInt();
		
		
		switch(choice){
		case 1:
			SavingsAcc savin = new SavingsAcc();
			savin.withdraw(amount);
			break;
		case 2:
			CurrentAcc curre = new CurrentAcc();
			curre.withdraw(amount);
			break;
		}
	}
}