public class CurrentAcc extends Account4_2{  


	

	double overdraft = 25000;

	public void withdraw(double amount){  
		if(overdraft >= amount){
			overdraft -= amount;
			System.out.println("transaction sucessfull");
			System.out.println("Remaining draft limit:"+overdraft);
		}
		else{
			System.out.println("transaction failed... over draft limit reached");
		}
	}
}