public class SavingsAcc extends Account4_2 {  

	
	double balan = 25000;
	public void withdraw(double amount) {
		if((balan-500) > amount){
			balan -= amount;
			System.out.println("transaction sucessful");
			System.out.println("Remaining balance:"+balan);
		}
		else{
			System.out.println("transaction failed.. insuffient balance or minimum balance to be maintained");
		}
	}
}