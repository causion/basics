package com.nt.five;
public class Account 
{
	private double accNum;
	protected double balance;
	private Person accHolder;
	public double getAccNum() {
		return accNum;
	}
	public void setAccNum(double accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public double deposit(double money)
	{
		balance=balance+money;
		return balance;
	}
	public double withDraw(double money)
	{
		balance=balance-money;
		
		return balance;
	}
}
