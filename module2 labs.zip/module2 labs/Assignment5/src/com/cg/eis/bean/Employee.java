package com.cg.eis.bean;


public class Employee 
{
	private int Id;
	private String Name;
	private float Sal;
	private String designation;
	private String insuranceScheme;
	public Employee(){}
	public int getEmpId() {
		return Id;
	}
	public void setEmpId(int empId) {
		this.Id = empId;
	}
	public String getEmpName() {
		return Name;
	}
	public void setEmpName(String empName) {
		this.Name = empName;
	}
	public float getEmpSal() {
		return Sal;
	}
	public void setEmpSal(float empSal) {
		this.Sal = empSal;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	
}
