package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.*;
import com.cg.eis.service.Service;
public class TestClientDemo 
{

	public static void main(String[] args) 
	{
		Scanner scn=new Scanner(System.in);
	   Employee emp=new Employee();
	   
	   
	   System.out.println("Enter Employee Id");
	   int id=scn.nextInt();
	   System.out.println("Enter Employee Name");
	   String name=scn.next();
	   System.out.println("Enter Employee Salary");
	   float sal=scn.nextFloat();
	   System.out.println("Enter Employee Designation  \n System_Associate \n Programmer \n Manager \n Clerk");
	   String designation=scn.next();
	   emp.setEmpId(id);
	   emp.setEmpName(name);
	   emp.setEmpSal(sal);
	   emp.setDesignation(designation);
	   Service ser=new Service();
	   
	  
	     System.out.println(ser.dispEmp(emp));
	   System.out.print("Scheme for Employee="+ser.medicalInsurance(emp));
	   scn.close();
	}

}
