package com.nt.f;

public abstract class Account {
	private double accNum;
	protected double balance;
	private Person accHolder;

	public double getAccNum() {
		return accNum;
	}

	public void setAccNum(double accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person smith) {
		this.accHolder = smith;
	}

	public double deposit(double money) {
		balance = balance + money;
		return balance;
	}

	public abstract double withDraw(double money);
}
