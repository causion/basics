package com.nt.f;

import java.util.Scanner;


public class TestClientAccount {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		Person smith=new Person();
		Person kathy=new Person();
		smith.setName("Smith");
		smith.setAge(20);
		kathy.setName("kathy");
		kathy.setAge(22);
		
		Account accSmith=new WithDrawFunction();
		Account accKathy=new WithDrawFunction();
		accSmith.setAccNum((double)Math.random()*100000);
		accSmith.setBalance(2000);
		accSmith.setAccHolder(smith);
		
		accKathy.setAccNum((double)Math.random()*10000);
		accKathy.setBalance(3000);
		accKathy.setAccHolder(kathy);
		int i=0;
		accKathy.withDraw(2000);
	System.out.println("Account holder Name="+accSmith.getAccHolder().getName()+"\nAge"+accSmith.getAccHolder().getAge());
	System.out.println("Account no="+accSmith.getAccNum()+"\nBalance="+accSmith.getBalance());
	System.out.println("----------------");
	System.out.println("Account holder Name="+accKathy.getAccHolder().getName()+"\nAge"+accKathy.getAccHolder().getAge());
	System.out.println("Account no="+accKathy.getAccNum()+"\nBalance="+accKathy.getBalance());
	System.out.println("------------------");
	int choice;
	
	System.out.println("In which acc you want to perform functions"
			+ "\n1) Smith Account  2)Kathy account");
	   i=scan.nextInt();
	
	System.out.println("Enter 1) deposit \t2)Withdraw");
	choice=scan.nextInt();
     Account accArr[]={accSmith,accKathy};
	switch(choice)
	{
	 	case 1:   System.out.println("Enter the amount you want to deposit");
		          double money=scan.nextDouble();
		          System.out.println("Amount Depost="+money);
		          accArr[choice-1].deposit(money);
		          System.out.println("Updated Balance"+accArr[i-1].getBalance());
		          break;
	 	
	 	case 2:   System.out.println("Enter the amount you want to withdraw");
	 			  money=scan.nextDouble();
                  System.out.println("Amount Withdraw="+money);
                  ((Account)accArr[i-1]).withDraw(money);
                  System.out.println("Updated Balance"+((Account)accArr[i-1]).getBalance());
                  break;
	 	default:   System.out.println("Enter the amount you want to deposit");
                    money=scan.nextDouble();
                   System.out.println("Amount Depost="+money);
                   accArr[i-1].deposit(money);
                   System.out.println("Updated Balance"+accArr[i-1].getBalance());  
                   break;
	}
	
	
	
		
		
		
	}

}
