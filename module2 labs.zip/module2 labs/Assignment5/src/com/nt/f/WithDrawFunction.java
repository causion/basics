package com.nt.f;

public class WithDrawFunction extends Account{

	@Override
	public double withDraw(double money) {
		if((balance-500) < money){
			System.out.println("insufficient balance");
		}
		else{
		balance -= money;
		}
		return balance;
	}

}
