package com.cg.assign;

public class Account {
	private long accNum;
	protected double balance;
	private Person accHolder;

	/*public Account(long accNum, double balance) {
		this.accNum = accNum;
		this.balance = balance;
		// this.accHolder = accHolder;
	}
*/
	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void display() {
		System.out.println(accNum + " \t" + getBalance());
	}

	public double deposit(double money) {

		setBalance(getBalance() + money);
		System.out.println(balance);
		return getBalance();
	}

	public double withDraw(double money){
		if(balance > money){
		setBalance(balance - money);
		System.out.println(balance);
		}
		else{
			System.out.println("insufficient funds");
		}
		return balance;
		
	}

	boolean search(long acn) {
		if (accNum == acn) {
			// showAccount();
			return (true);
		}
		return (false);
	}

}
