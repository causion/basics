package com.cg.assign;

public class AgeException extends Exception{
	public AgeException(){
		super();
	}
}
