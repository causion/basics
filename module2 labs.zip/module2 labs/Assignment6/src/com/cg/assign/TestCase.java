package com.cg.assign;

import java.util.*;

public class TestCase {
	public static void main(String[] args) {
		boolean found;
		long accno;
		String name;
		float age;
		int i, choice;
		double balance, money;
		Scanner scn = new Scanner(System.in);
		Random rand = new Random();
		System.out.println("How many bank accounts u want to enter");
		int n = scn.nextInt();
		Account a[] = new Account[n];
		Person p[] = new Person[n];
		for (i = 0; i < n; i++) {
			accno = rand.nextInt(1000) + 1000;
			System.out.println("enter name");
			name = scn.next();
			System.out.println("enter age");
			age = scn.nextFloat();
			System.out.println("enter balance");
			balance = scn.nextDouble();

			if (age > 15) {
				p[i] = new Person();
				a[i] = new Account();
				
			} else {
				try {
					throw new AgeException();
				} catch (AgeException e) {
					e.printStackTrace();
				}
			}
			p[i].setName(name);
			p[i].setAge(age);
			a[i].setBalance(balance);
			a[i].setAccNum(accno);
			System.out.println(accno + "\t" + name + "\t" + age + "\t"+ balance);
		}

		System.out.println("enter your account number");
		long acn = scn.nextLong();
		found = false;
		for (i = 0; i < a.length; i++) {
			found = a[i].search(acn);
			if (found) {
				// System.out.println("On which account you want to perform operation \n 1.Savings Account \n 2.Current Account");
				System.out.println("Enter your choice \n 1.deposit 2.withdraw");
				choice = scn.nextInt();
				switch (choice) {
				case 1:
					System.out.println("enter amount u want to deposit");
					money = scn.nextDouble();
					a[i].deposit(money);
					break;
				case 2:
					System.out.println("enter amount you want to withdraw");
					money = scn.nextDouble();
					a[i].withDraw(money);
					break;
				}
				if (!found) {
					System.out.println("Account not found");
				}
			}
		}
	}
}
