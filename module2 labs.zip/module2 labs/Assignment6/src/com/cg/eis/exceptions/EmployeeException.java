package com.cg.eis.exceptions;

public class EmployeeException extends RuntimeException{
     public EmployeeException() {
    	 super();
		System.out.println("employee salary cannot be not less than 3000");
    	
	}
}
