package com.cg.eis.service;

import com.cg.eis.bean.Employee;
// without exception it is lab 5.1 or it is 6.3
import com.cg.eis.exceptions.EmployeeException;


public class Service implements EmployeeService{
	
	public static String scheme;
	public Service(){};
	
	
	
	
	@Override
	public String medicalInsurance(Employee emp) throws EmployeeException
	{	
		if(emp.getEmpSal() > 3000){
		if(emp.getDesignation().equals("System_Associate") || emp.getEmpSal()>=5000 && emp.getEmpSal()<20000)
		{
			scheme = "Scheme C";
			return scheme;
		}
		else if(emp.getDesignation().equals("Programmer") || emp.getEmpSal()>=20000 && emp.getEmpSal()<40000)
		{
			scheme =  "Scheme B";
			return scheme;
		}
		else if(emp.getDesignation().equals("Manager") || emp.getEmpSal()>=40000)
		{
			scheme =  "Scheme A";
			return scheme;
		}
		else if(emp.getDesignation().equals("Clerk") || (emp.getEmpSal()<5000))
		{
			scheme =  "No Scheme";
			return scheme;
		}}
		else
		{
			throw new EmployeeException();
		}
		return scheme;
		
	}
	

	
	public String dispEmp(Employee emp)
	{
		return "Emp name="+emp.getEmpName()+"\nEmp ID="+emp.getEmpId()+"\nEmp Salary"+emp.getEmpSal()+
				"\nEmp Dessignation="+emp.getDesignation();
	}
	
	
	
}
