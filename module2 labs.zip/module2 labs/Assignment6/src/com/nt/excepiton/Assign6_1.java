package com.nt.excepiton;

import java.util.Scanner;

@SuppressWarnings("unused")
public class Assign6_1 {
	private static String fname;
	private static String lname;
	private String gend;

	public static String getFname() {
		return fname;
	}

	public static void setFname(String fname) {
		Assign6_1.fname = fname;
	}

	public static String getLname() {
		return lname;
	}

	public static void setLname(String lname) {
		Assign6_1.lname = lname;
	}

	public Assign6_1(String fname, String lname) {
		this.fname = fname;
		this.lname = lname;

		if (fname.equals("") && lname.equals("")) {
			// if(fname.isEmpty() && lname.isEmpty())

			try {
				throw new InvalidEntry("please enter valid name");
			} catch (InvalidEntry e) {
				e.printStackTrace();
			}

		} else {
			System.out.println(fname + lname);
			System.out.println(" u may proceed");

		}
	}

}
