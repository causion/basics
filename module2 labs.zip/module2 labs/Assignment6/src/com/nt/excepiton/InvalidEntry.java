package com.nt.excepiton;

public class InvalidEntry extends Exception{
	public InvalidEntry(String msg){
		System.out.println("please enter valid name");
	}
}
