package com.nt.excepiton;

import java.util.Scanner;

public class persondetails {
	public static String fname,lname;
	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter First name");
		fname = scn.nextLine();
		System.out.println("Enter Last name");
		lname = scn.nextLine();
		Assign6_1 s= new Assign6_1(fname,lname);
	}

}
