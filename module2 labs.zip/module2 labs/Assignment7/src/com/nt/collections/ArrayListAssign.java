package com.nt.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListAssign {

	public static void main(String[] args) {

		List<String> l = new ArrayList<String>();
		l.add("Apple");
		l.add("Nokia");
		l.add("Samsung");
		l.add("mi");
		System.out.println("Before sorting"+l);
		Collections.sort(l);
		for (String string : l) {
			System.out.println("After sorting"+string);
		}
	}
}
