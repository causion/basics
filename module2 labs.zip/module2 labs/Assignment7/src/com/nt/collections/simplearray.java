package com.nt.collections;

import java.util.Arrays;

public class simplearray {

	public static void main(String[] args) {
		String arr[] = { "apple", "mi", "samsung", "nokia" };
		/*for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}*/
		Arrays.sort(arr);
		/*for (String string : arr) {
			System.out.println(string);

		}*/
	}

}
