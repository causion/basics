import java.io.File;
import java.util.Scanner;

public class ReadNumbers {

    public static void main(String[] args) {
        Scanner input = null;
        try {
            input = new Scanner(new File("numbers.txt"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

       @SuppressWarnings("unused")
	int sum = 0;
        int evenCounter=0,totalcount=0;
        while(input.hasNextDouble()) {
            int next = input.nextInt();
            sum += next;
            totalcount++;
            if(next%2==0){
                evenCounter++;
                System.out.println(next);
            }
        }
        System.out.println("total numbers:"+totalcount);
        System.out.println("Even Numbers: "+evenCounter);
    }
}