
import org.junit.Assert;
import org.junit.Test;


public class JunitTest {
   @Test
   public void testGetFirstName(){
		Person per = new Person("ram","Sham");
		Assert.assertEquals("ram",per.getFirstName());
	}
  @Test
   public void testGetLastName(){
		Person per= new Person("Raghav","singh");
		Assert.assertEquals("singh",per.getLastName());
   }
  
	}