console.log("Welcome to TypeScript");
var a = 10;
var b = 20;
var c = a + b;
console.log("sum=" + c);
