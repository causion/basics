console.log("Welcome to TypeScript");
var a:number=10;
var b:number=20;
var c:number=a+b;
console.log("sum="+c);
