var sum=(x:number,y:number):number=>{return x+y};
var sum1=(x,y)=>{return x+y};
var sum2=(x,y)=>x+y;
var hi=()=>console.log("say Hi");
var printname=(name)=>{console.log("welcome");
console.log(name);}
console.log("Sum="+sum(10,20));
console.log("Sum1="+sum1(11,22));
console.log("Sum2="+sum2(20,20));
hi();
printname("kanna");