var empName:string;
var empStatus:boolean;
var data:any;
var numValues:number[]=[10,20,30,40];
var datas:any[]=[99,'siva',false,45.6];
empName='ABCD';
empStatus=true;
data="anydata";
const PI=3.14;

enum Color {Red=1,Green=2,Blue=3};
console.log("Name:"+empName);
console.log("Status:"+empStatus);
console.log("Data:"+data);
console.log("numeric array:"+numValues);
console.log("datas:"+datas);
console.log("PI:"+PI);
console.log("Red:"+Color.Red);


