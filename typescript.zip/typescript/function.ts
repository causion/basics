let addition=function(a,b){
    return a+b;
}
console.log(addition(10,20));
function  multiply(a,b){
    return a*b;
}
let mul=multiply(10,20);
console.log("Multiply value:"+mul);

function show(name){
    console.log("Welcome"+name);
}
show("Jaswanth");
