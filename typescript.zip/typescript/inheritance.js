var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Employee = /** @class */ (function () {
    function Employee(empId, name, salary) {
        this.empId = empId;
        this.name = name;
        this.salary = salary;
        Employee.noOfEmployees++;
    }
    Employee.prototype.display = function () {
        console.log("ID:" + this.empId + "\n Name: " + this.name + "\nSalary:" + this.salary + "\nNo.OfEmployees:" + Employee.noOfEmployees);
    };
    Employee.noOfEmployees = 0;
    return Employee;
}());
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(empId, name, salary, noOfReporties) {
        var _this = _super.call(this, empId, name, salary) || this;
        _this.noOfReporties = noOfReporties;
        return _this;
    }
    Manager.prototype.display = function () {
        _super.prototype.display.call(this);
        console.log("NoOfReporties:${this.noOfReporties}");
    };
    return Manager;
}(Employee));
var e = new Employee(123, "Jaswanth", 66689);
var m = new Manager(124, "siva", 89898, 5);
e.display();
m.display();
console.log(Employee.noOfEmployees);
