var empArray = [];
empArray.push({
    fname: "kanna", lname: "G", phone: 9550673666
});
empArray.push({
    fname: "Jaswanth", lname: "G", phone: 998989868
});
for (var _i = 0, empArray_1 = empArray; _i < empArray_1.length; _i++) {
    var e = empArray_1[_i];
    console.log("FirstName:" + e.fname + "\tLastName:" + e.lname + "\tSalary:" + e.phone);
}
