interface Employee{
    fname:string;
    lname:string;
    phone:number;

}

let empArray:Employee[]=[];
empArray.push({
    fname:"kanna",lname:"G",phone:9550673666
});

empArray.push({
    fname:"Jaswanth",lname:"G",phone:998989868
});

for(var e of empArray){
    console.log("FirstName:"+e.fname+"\tLastName:"+e.lname+"\tSalary:"+e.phone)
}
