var n1 = 10;
function myfunction() {
    var n2 = 20;
    if (n2 > n1) {
        var n3 = 30;
    }
    console.log("n1=" + n1);
    console.log("n2=" + n2);
    //console.log("n3="+n3);
}
myfunction();
console.log("n1=" + n1);
//console.log("n2="+n2);// var has function scope
// u can't access
//console.log("n3="+n3);
