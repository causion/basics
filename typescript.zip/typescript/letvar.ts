let n1:number=10;
function myfunction(){
    let  n2:number=20;
    if(n2>n1){
        let n3:number=30;
    }
    console.log("n1="+n1);
    console.log("n2="+n2);
    //console.log("n3="+n3);
}
myfunction();
console.log("n1="+n1); 

    //console.log("n2="+n2);// var has function scope
    // u can't access
    //console.log("n3="+n3);