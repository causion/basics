"use strict";
exports.__esModule = true;
var propArray = [
    { pid: 1001, pname: "Mobile", price: 78787 },
    { pid: 1002, pname: "Laptop", price: 88787 },
    { pid: 1003, pname: "Monitor", price: 8787 },
];
for (var _i = 0, propArray_1 = propArray; _i < propArray_1.length; _i++) {
    var p = propArray_1[_i];
    console.log("pid:" + p.pid + "\tName:" + p.pname + "\tPrice:" + p.price);
}
