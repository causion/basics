import {Product} from "./Product";
let propArray:Product[]=[
    {pid:1001,pname:"Mobile",price:78787},
    {pid:1002,pname:"Laptop",price:88787},
    {pid:1003,pname:"Monitor",price:8787},
];

for(var p of propArray){
console.log("pid:"+p.pid+"\tName:"+p.pname+"\tPrice:"+p.price);
}