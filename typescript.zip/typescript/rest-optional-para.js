function sumAll() {
    var n = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        n[_i] = arguments[_i];
    }
    var sum = 0;
    for (var _a = 0, n_1 = n; _a < n_1.length; _a++) {
        var v = n_1[_a];
        sum = sum + v;
    }
    alert("Sum=" + sum);
    document.write("<br>Total:" + sum);
}
sumAll(10, 20, 30, 40, 50);
sumAll();
sumAll(11, 22);
function hello(one, two, three) {
    if (two === void 0) { two = 99; }
    document.write("<br> 1=" + one);
    document.write("<br> 2=" + two);
    document.write("<br> 3=" + three);
}
hello(55);
hello(11, 22);
hello(7, 8, 9);
