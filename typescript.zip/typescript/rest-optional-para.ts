function sumAll(...n:number[]){
    let sum=0;
    for(var v of n){
        sum=sum+v;
    }
    alert("Sum="+sum);
    document.write("<br>Total:"+sum);
}
sumAll(10,20,30,40,50);
sumAll();
sumAll(11,22);
function hello(one:number,two=99,three?:number){
    document.write("<br> 1="+one);
    document.write("<br> 2="+two);
    document.write("<br> 3="+three);
}
hello(55);
hello(11,22);
hello(7,8,9);